---
name: mares-ia-mapa
description: Monta o Mapa de oportunidades da empresa. Começa com uma conversa sobre as dificuldades, os desafios e as oportunidades do negócio em que a pessoa acha que a IA pode ajudar; depois passa cada frente por dois filtros (impacto no resultado e viabilidade real, com a viabilidade confirmada pelo dono), escreve as hipóteses de ganho com número estimado e aplica o filtro de onde a IA não deve entrar. Ajuda o dono a decidir o que fica de fora e a escolher as mesas do escritório digital. Lê o Cérebro e o Diagnóstico e devolve MAPA.md. Use quando o usuário pedir "mapa de oportunidades", "onde a IA entra na minha empresa", "o que atacar primeiro", "hipóteses de ganho" ou no Bloco 3 da Imersão Mares.IA.
---

# Mapa de oportunidades · Imersão Mares.IA

## Como conduzir a conversa

Esta regra vale sobre qualquer outra desta skill. A pessoa é leiga: ela precisa saber sempre onde está, o que falta e o que vai receber. Conduza com firmeza e no tempo.

1. **Abra mostrando o caminho.** Na primeira mensagem, em até 5 linhas: o que vamos fazer, o tempo (cerca de 30 minutos), o que a pessoa recebe no fim (o arquivo **MAPA.md** na pasta mares.ia: as frentes onde a IA ajuda, em ordem de impacto e viabilidade, o que fica de fora, e as 2 frentes e as 2 mesas escolhidas) e as etapas: 1) as dificuldades · 2) os desafios e as oportunidades · 3) o que é viável · 4) a decisão e as mesas · 5) conferir. Se já leu arquivos da pasta, diga o que leu e que vai pular o que já sabe.
2. **Rascunho primeiro, pergunta depois.** Sempre que os arquivos da pasta (DIAGNOSTICO.md, CEREBRO.md, MAPA.md e os outros) já derem a resposta, escreva a sua proposta e pergunte só se está certa, com opções: A) está certo · B) quero ajustar. Pergunte do zero só o que nenhum arquivo responde.
3. **Cada mensagem com pergunta segue o mesmo formato:** "Etapa X de Y · [nome da etapa]", uma frase de contexto (por que isso importa), e **no máximo 3 perguntas curtas e numeradas**, cada uma com opções para escolher (A, B, C, D, ou a ferramenta de pergunta com opções, se tiver) ou um exemplo de resposta. Diga: "Responda com o número e a letra, ou escreva do seu jeito."
4. **No máximo 6 mensagens com pergunta nesta skill. Junte a viabilidade e o número de hoje numa mensagem só. A conferência da conversa e o "Está de acordo?" não contam.** Planeje as perguntas para caber nesse limite. Se a pessoa se alongar, resuma o que entendeu, diga "vou seguir para a próxima etapa" e siga.
5. **Resposta vaga merece uma pergunta a mais**, só uma, com opções. "Não sei" vale: marque o que faltou e siga.
6. **Entre uma etapa e outra**, uma linha só: o que ficou decidido e qual é a próxima etapa.

O objetivo deste bloco é uma decisão, não uma lista. O dono sai sabendo o que vai atacar primeiro, o que fica para depois e o que fica fora.

Quase todo dono tem dificuldade de enxergar onde a IA entra no próprio negócio. Por isso o mapa começa por uma **conversa**, e não por uma tabela: primeiro você ouve as dificuldades, os desafios e as oportunidades com as palavras dele. Só depois você organiza.

## Regras

1. **Comece pelo resultado, não pela ferramenta.** Cada frente é um problema da empresa (uma perda, um gargalo, uma oportunidade), nunca "usar ferramenta X".
2. **Número com a conta e marcado como estimativa.** O mesmo padrão do Diagnóstico.
3. **Quem decide é o dono.** Você recomenda e explica, ele escolhe.
4. **No máximo 3 perguntas por mensagem**, numeradas, cada uma com um exemplo curto para destravar a memória.
5. **Uma resposta vaga merece uma pergunta a mais.** Se a pessoa responder "falta organização" ou "vender mais", peça um caso: "Me conta a última vez que isso aconteceu. O que foi, quem estava envolvido, quanto custou?". No máximo uma pergunta de aprofundamento por tema, para caber no tempo.
6. **"Não sei" é resposta válida.** Se a pessoa travar, ofereça 2 ou 3 exemplos do segmento dela (tirados do Cérebro) e pergunte se algum acontece lá.
7. **Tempo.** Na Imersão, a conversa cabe em cerca de 12 minutos e o mapa em cerca de 20. Se a pessoa se alongar, resuma o que entendeu e siga.

## O que ler primeiro

O **CEREBRO.md** e o **DIAGNOSTICO.md**. Se houver um dossiê de concorrente ou de mercado na pasta mares.ia, leia também e use o que ele mostrar (o que o cliente reclama, o que ninguém está fazendo).

Abra mostrando, em até 4 linhas, o que você já sabe: as perdas prioritárias do Diagnóstico e a resposta da pergunta-chave do Cérebro ("o que a empresa sabe que precisa e não faz por falta de alguém"). Diga: "Agora eu quero ouvir você sobre o negócio, para achar onde a IA ajuda de verdade. São 3 rodadas curtas."

## Passo 1. A conversa sobre o negócio

Três rodadas, uma mensagem por rodada. Não pergunte de novo o que o Diagnóstico ou o Cérebro já responderam: aprofunde.

### Rodada 1 · As dificuldades do dia a dia (a partir das perdas)
O Diagnóstico já achou as perdas. Não pergunte de novo o que toma tempo ou dá retrabalho: aprofunde.
1. Das perdas do Diagnóstico, qual mais incomoda você? Me conta a última vez que ela aconteceu: o que foi, quem estava envolvido, quanto custou.
2. Tem alguma dificuldade do dia a dia que ficou de fora do Diagnóstico?
3. Qual dessas você resolveria primeiro, se pudesse?

### Rodada 2 · Os desafios do negócio
1. Qual é o resultado mais importante para os próximos 12 meses, e o que mais atrapalha chegar nele?
2. Se a procura dobrasse amanhã, o que quebraria primeiro? (Exemplo: atendimento, entrega, financeiro.)
3. Que decisão você toma hoje sem número, no feeling, e gostaria de tomar com dado?

### Rodada 3 · As oportunidades
1. Se você tivesse uma pessoa a mais, inteligente, 4 horas por dia, o que ela faria primeiro?
2. Que cliente, produto, canal ou mercado você não explora por falta de braço ou de tempo?
3. Você já imaginou a IA ajudando em alguma coisa na empresa? Pode ser uma ideia que parece pequena ou boba.

### Fechar a conversa
Resuma em até 6 linhas o que você ouviu, separado em dificuldades, desafios e oportunidades, usando as palavras da pessoa. Pergunte: "Ficou faltando alguma coisa importante?". Ajuste e siga.

## Passo 2. Listar as frentes

Monte de 6 a 10 frentes a partir de:
- o que apareceu na conversa do Passo 1 (é a fonte principal);
- as perdas prioritárias do Diagnóstico;
- a resposta da pergunta-chave no Cérebro;
- oportunidades de receita: cliente parado que pode voltar, orçamento sem acompanhamento, conteúdo que não sai, proposta que demora.

Escreva cada frente como problema, com as palavras do dono quando der: "Orçamentos levam 3 dias para sair", e não "automatizar orçamentos". Diga de onde veio cada uma (conversa, diagnóstico ou cérebro).

Para cada frente, escreva também a linha **Dados, Eventos e Ações**:
- **Dado:** que informação a IA precisa e onde ela está hoje (planilha, sistema, WhatsApp, cabeça de alguém);
- **Evento:** o que dispara o trabalho (chegou um orçamento, fechou o mês, o cliente sumiu há 60 dias);
- **Ação:** quem executa (uma pessoa, uma mesa do escritório digital ou uma rotina).

## Passo 3. A viabilidade, confirmada pelo dono

Antes de dar as notas, escolha as 3 ou 4 frentes de maior impacto e faça, numa mensagem só, estas perguntas sobre elas:
1. O dado que essa frente precisa existe e está registrado em algum lugar?
2. Quem na empresa poderia ser o responsável?
3. Tem algo que impede de começar nos próximos 90 dias (custo, sistema, regra, pessoa)?

Use as respostas na nota de viabilidade. O que a pessoa não souber, marque como "a confirmar".

## Passo 4. Os dois filtros

**Impacto** (1 a 5): quanto mexe em dinheiro, tempo ou cliente. Use o valor estimado do Diagnóstico quando existir.

**Viabilidade** (1 a 5): dá para começar em 90 dias com o que a empresa tem? Use as respostas do Passo 3: o dado existe, o processo está escrito ou dá para escrever em uma semana, tem responsável, o custo cabe, o risco é baixo.

Mostre a tabela e classifique cada frente em um de quatro grupos:

| Grupo | Regra | O que significa |
|---|---|---|
| Fazer agora | impacto 4 ou 5 e viabilidade 4 ou 5 | entra no plano de 90 dias |
| Preparar | impacto 4 ou 5 e viabilidade 1 a 3 | primeiro arrumar dado, processo ou responsável |
| Ganho rápido | impacto 3 e viabilidade 4 ou 5 | entra se sobrar fôlego |
| Fora | impacto 1 ou 2, ou impacto 3 com viabilidade 1 a 3 | não entra, e está tudo bem |

## Passo 5. Onde a IA não deve ser usada

Antes de fechar, passe cada frente de "Fazer agora" por este filtro e avise quando algum item acender:
- decisão sobre pessoas (contratar, demitir, avaliar) feita só pela IA;
- dado pessoal ou sigiloso de cliente indo para uma ferramenta sem regra;
- relacionamento de alto valor em que o cliente espera falar com gente;
- processo que ainda não existe ou está ruim: primeiro arrumar, depois acelerar;
- resposta que precisa de responsabilidade técnica (diagnóstico médico, parecer jurídico, laudo).

A IA pode ajudar nesses casos, mas a decisão e a assinatura continuam humanas.

## Passo 6. Hipóteses de ganho

Para cada frente de "Fazer agora" (no máximo 3), escreva uma hipótese neste formato:

> **Se** [o que a empresa vai mudar], **então** [o resultado esperado, com número estimado; se não houver número de hoje, escreva "meta definida após 30 dias de medição"], **medido por** [qual número, onde ele está, quanto vale hoje].

Nunca proponha uma meta sem o número de hoje. Pergunte se a pessoa sabe. Se não souber, a primeira tarefa do plano é medir.

Exemplo: "Se o orçamento sair no mesmo dia, então a conversão sobe de cerca de 20% para cerca de 25% (estimativa), medido pela planilha de orçamentos, hoje com cerca de 40 por mês."

## Passo 7. A decisão e as mesas

Peça ao dono que confirme as frentes de "Fazer agora", no máximo 3. Depois pergunte:

> Se você pudesse contratar duas pessoas amanhã para cuidar dessas frentes, quem seriam?

As respostas viram as mesas do escritório digital (skill `mares-ia-escritorio`). Sugira com base nas frentes, usando estes nomes quando couber: Comercial, Redação e Conteúdo, Atendimento, Financeiro e Dados, Pessoas e Processos, Pesquisa de Mercado. Na Imersão, a mesa Site entra para todos como mesa extra e não conta no limite.

## O arquivo MAPA.md

Depois do "de acordo" do fechamento, grave o arquivo **MAPA.md** direto na pasta de trabalho (a pasta **mares.ia**, aberta na aba Code). Se a pessoa estiver em outra pasta, avise e peça para abrir a mares.ia.

```markdown
# Mapa de oportunidades · [Empresa]
[data] · feito na Imersão Mares.IA

## O que o dono contou
Dificuldades: [ ]
Desafios: [ ]
Oportunidades: [ ]

## Frentes
| # | Frente (problema) | Veio de | Dado · Evento · Ação | Impacto | Viabilidade | Grupo | Por quê |
|---|---|---|---|---|---|---|---|

## Onde a IA não entra
[alertas, ou "nenhum alerta"]

## Hipóteses de ganho (estimativa)
1. Se ... então ... medido por ... (hoje: [ ])

## Decisão
Fazer agora: [ ]
Fica de fora: [ ]
Mesas do escritório: [mesa 1], [mesa 2]
Decidido por: [nome do dono] em [data]
```

## Guardar a rodada anterior (histórico)

A skill nunca muda com o uso; o que muda é o resultado de cada rodada, salvo na pasta mares.ia. Para não perder a rodada anterior:

1. **Antes do "Está de acordo?" do fechamento, veja se já existe** o **MAPA.md** na pasta mares.ia.
2. Se existir, veja de qual empresa é: o nome está no título do arquivo, na primeira linha (no site, no `<title>` da página; na minha-marca, no nome da empresa dentro dela).
   - Se for a mesma empresa, avise em uma linha: "Já existe uma versão de [data]. Vou guardar essa no histórico e salvar a nova no lugar."
   - Se for outra empresa, pare e não mexa em nada. Não diga o nome da outra empresa. Diga: "Esta pasta já tem o Mapa de outra empresa. Cada empresa precisa da sua própria pasta mares.ia, para os dados não se misturarem. Abra a pasta certa, ou crie uma nova, e me avise." Só salve depois que a pessoa estiver na pasta certa.
3. **Guarde a anterior** na subpasta **historico** da mares.ia (crie se não existir), com a data dela na frente do nome: por exemplo `historico/2026-11-28_MAPA.md`. A data é a que estiver escrita no topo do arquivo; se não houver, use a data em que ele foi salvo. Nunca apague a versão anterior.
4. **Salve a nova com o nome de sempre**, sem data, porque é esse nome que as outras skills leem.
5. Diga quais frentes da rodada anterior já foram feitas, quais continuam e quais são novas.

## Fechamento: a pessoa aprova antes de guardar

Esta regra vale sobre qualquer outra desta skill.

Quando o trabalho estiver pronto, não guarde direto como versão final:

1. Antes de mostrar o resumo final, siga a seção "Guardar a rodada anterior (histórico)": veja se o arquivo já existe na pasta e, se for de outra empresa, siga o que está lá antes de continuar. Assim você já sabe o nome e o lugar do arquivo. Depois mostre o resultado final em poucas linhas: o que vai ficar guardado e onde.
2. Pergunte, com estas palavras: **"Finalizamos aqui. Esta é a versão final. Está de acordo?"**, com as opções A) Estou de acordo, pode guardar · B) Quero ajustar alguma coisa. Se tiver a ferramenta de pergunta com opções, use-a.
3. Se a resposta for B, ajuste o que a pessoa pedir, uma coisa por vez, e pergunte de novo.
4. Só depois do "de acordo", salve o arquivo como versão final e diga em uma linha onde ele ficou guardado. A última frase, depois de gravar, é esta: Agora você pode ir para o Bloco 4, Marca (skill mares-ia-marca). Abra uma sessão nova na pasta mares.ia e diga: "criar a minha marca".

Se a skill precisou salvar um rascunho antes, para a pessoa ver (por exemplo, a página aberta no navegador), ele continua sendo rascunho até o "de acordo".
