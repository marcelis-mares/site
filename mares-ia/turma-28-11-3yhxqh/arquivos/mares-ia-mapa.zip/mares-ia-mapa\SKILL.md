---
name: mares-ia-mapa
description: Monta o Mapa de oportunidades da empresa, com cada frente passando por dois filtros (impacto no resultado e viabilidade real), as hipóteses de ganho com número estimado e o filtro de onde a IA não deve entrar. Ajuda o dono a decidir o que fica de fora e a escolher as mesas do escritório digital. Lê o Cérebro e o Diagnóstico e devolve MAPA.md. Use quando o usuário pedir "mapa de oportunidades", "onde a IA entra na minha empresa", "o que atacar primeiro", "hipóteses de ganho" ou no Bloco 3 da Imersão Mares.IA.
---

# Mapa de oportunidades · Imersão Mares.IA

O objetivo deste bloco é uma decisão, não uma lista. O dono sai sabendo o que vai atacar primeiro, o que fica para depois e o que fica fora.

## Regras

1. **Comece pelo resultado, não pela ferramenta.** Cada frente é um problema da empresa (uma perda, um gargalo, uma oportunidade), nunca "usar ferramenta X".
2. **Número com a conta e marcado como estimativa.** O mesmo padrão do Diagnóstico.
3. **Quem decide é o dono.** Você recomenda e explica, ele escolhe. Se houver um líder junto, peça que os dois concordem.
4. **No máximo 3 perguntas por mensagem.**

## O que ler primeiro

O **CEREBRO.md** e o **DIAGNOSTICO.md**. Se houver um dossiê de concorrente ou de mercado na Pasta da Empresa, leia também e use o que ele mostrar (o que o cliente reclama, o que ninguém está fazendo).

## Passo 1. Listar as frentes

Monte de 6 a 10 frentes a partir de:
- as 5 maiores perdas do Diagnóstico;
- a resposta da pergunta-chave no Cérebro ("o que a empresa sabe que precisa e não faz por falta de alguém");
- oportunidades de receita: cliente parado que pode voltar, orçamento sem acompanhamento, conteúdo que não sai, proposta que demora.

Escreva cada frente como problema: "Orçamentos levam 3 dias para sair" e não "automatizar orçamentos".

## Passo 2. Os dois filtros

**Impacto** (1 a 5): quanto mexe em dinheiro, tempo ou cliente. Use o valor estimado do Diagnóstico quando existir.

**Viabilidade** (1 a 5): dá para começar em 90 dias com o que a empresa tem? Olhe:
- o dado necessário existe?
- o processo está escrito ou dá para escrever em uma semana?
- tem alguém para ser o responsável?
- o custo cabe? o risco é baixo?

Mostre a tabela e classifique cada frente em um de quatro grupos:

| Grupo | Regra | O que significa |
|---|---|---|
| Fazer agora | impacto 4 ou 5 e viabilidade 4 ou 5 | entra no plano de 90 dias |
| Preparar | impacto 4 ou 5 e viabilidade 1 a 3 | primeiro arrumar dado, processo ou responsável |
| Ganho rápido | impacto 3 e viabilidade 4 ou 5 | entra se sobrar fôlego |
| Fora | impacto 1 ou 2, ou impacto 3 com viabilidade 1 a 3 | não entra, e está tudo bem |

## Passo 3. Onde a IA não entra

Antes de fechar, passe cada frente de "Fazer agora" por este filtro e avise quando algum item acender:
- decisão sobre pessoas (contratar, demitir, avaliar) feita só pela IA;
- dado pessoal ou sigiloso de cliente indo para uma ferramenta sem regra;
- relacionamento de alto valor em que o cliente espera falar com gente;
- processo que ainda não existe ou está ruim: primeiro arrumar, depois acelerar;
- resposta que precisa de responsabilidade técnica (diagnóstico médico, parecer jurídico, laudo).

A IA pode ajudar nesses casos, mas a decisão e a assinatura continuam humanas.

## Passo 4. Hipóteses de ganho

Para cada frente de "Fazer agora" (no máximo 3), escreva uma hipótese neste formato:

> **Se** [o que a empresa vai mudar], **então** [o resultado esperado, com número estimado; se não houver número de hoje, escreva "meta definida após 30 dias de medição"], **medido por** [qual número, onde ele está, quanto vale hoje].

Nunca proponha uma meta sem o número de hoje.

Exemplo: "Se o orçamento sair no mesmo dia, então a conversão sobe de cerca de 20% para cerca de 25% (estimativa), medido pela planilha de orçamentos, hoje com cerca de 40 por mês."

O número de hoje é o "antes". Pergunte se a pessoa sabe. Se não souber, a primeira tarefa do plano é medir.

## Passo 5. A decisão e as mesas

Peça ao dono que confirme as frentes de "Fazer agora", no máximo 3. Depois pergunte:

> Se você pudesse contratar duas pessoas amanhã para cuidar dessas frentes, quem seriam?

As respostas viram as mesas do escritório digital (skill `mares-ia-escritorio`). Sugira com base nas frentes, usando estes nomes quando couber: Comercial, Redação e Conteúdo, Atendimento, Financeiro e Dados, Pessoas e Processos, Pesquisa de Mercado. Na Imersão, a mesa Site entra para todos como mesa extra e não conta no limite.

## O arquivo MAPA.md

Gere para download (ou bloco de código) e peça para adicionar ao projeto.

```markdown
# Mapa de oportunidades · [Empresa]
[data] · feito na Imersão Mares.IA

## Frentes
| # | Frente (problema) | Impacto | Viabilidade | Grupo | Por quê |
|---|---|---|---|---|---|

## Onde a IA não entra
[alertas, ou "nenhum alerta"]

## Hipóteses de ganho (estimativa)
1. Se ... então ... medido por ... (hoje: [ ])

## Decisão
Fazer agora: [ ]
Fica fora: [ ]
Mesas do escritório: [mesa 1], [mesa 2]
Decidido por: [nome do dono] em [data]
```
