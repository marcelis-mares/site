---
name: mares-ia-plano-90
description: Fecha o Plano de ação de 90 dias da empresa, com no máximo 3 prioridades, responsável com nome, prazo com data, número de antes e como medir, o que a empresa deixa de fazer, o ritual semanal de acompanhamento e a regra de uso de IA da empresa. Lê o Cérebro, o Diagnóstico, o Mapa e o Escritório e devolve PLANO-90.md. Use quando o usuário pedir "plano de 90 dias", "plano de ação", "regra de uso de IA", "política de IA da empresa" ou no Bloco 6 da Imersão Mares.IA.
---

# Plano de 90 dias · Imersão Mares.IA

Plano bom é o que cabe na segunda-feira. Este bloco transforma as decisões do dia em compromisso com nome e data.

**A condição que vale o bloco inteiro:** a transformação acontece quando o dono conduz, não quando o dono delega. O dono decide prioridade e o que deixa de fazer. O líder assume a execução e o ritmo.

## Regras

1. **No máximo 3 prioridades.** Se o dono quiser mais, pergunte qual delas ele tiraria se tivesse que escolher. Nem tudo ao mesmo tempo.
2. **Toda ação tem nome e data.** "Comercial" não é responsável. "Ana, até 15/12" é.
3. **Toda prioridade tem um número.** O número de hoje (antes) e onde ele será medido. Se não existir, a primeira ação é medir.
4. **Datas reais.** Confira a data de hoje e conte os 90 dias a partir da próxima segunda-feira: o dia 90 é 89 dias depois do início. Avise se o período pega feriado ou fim de ano e ajuste os prazos dos primeiros 30 dias.
5. **Sem líder também funciona.** Se o dono veio sozinho e não tem líder, o dono acompanha e o responsável de cada ação é quem faz a tarefa.
6. **No máximo 3 perguntas por mensagem.** Proponha um rascunho completo primeiro e peça só as correções: é mais rápido do que perguntar item por item.

## O que ler primeiro

CEREBRO.md, DIAGNOSTICO.md, MAPA.md e ESCRITORIO.md, se estiverem no projeto. Use as frentes de "Fazer agora" do Mapa como ponto de partida. Mostre o que você leu e proponha um rascunho, em vez de perguntar do zero.

## Passo 1. As prioridades

Para cada prioridade (máximo 3):
- **Objetivo** em uma frase, ligado a uma frente do Mapa.
- **Número:** valor de hoje, meta em 90 dias (estimativa), onde se mede.
- **Responsável:** uma pessoa com nome.
- **Mesa do escritório** que ajuda, se houver.

## Passo 2. As ações em três tempos

| Tempo | Foco |
|---|---|
| Dias 1 a 30 | arrumar a base: medir, escrever o processo, testar com poucos casos |
| Dias 31 a 60 | rodar de verdade e corrigir |
| Dias 61 a 90 | consolidar, medir o resultado, decidir o próximo passo |

Cada ação tem: o que é, responsável, data e como se sabe que ficou pronta. No máximo 2 ações por prioridade em cada tempo. Na Imersão, detalhe os dias 1 a 30 e deixe uma linha só para cada um dos outros dois tempos.

## Passo 3. O que a empresa deixa de fazer

Pergunte ao dono: "Para caber isso, o que a empresa para de fazer, ou faz menos?". Registre pelo menos uma coisa. Sem isso, o plano disputa tempo com a rotina e perde.

## Passo 4. O ritual

Proponha uma reunião semanal de 30 minutos, sempre no mesmo dia e hora, com três perguntas:
1. O número de cada prioridade andou?
2. O que travou e quem destrava?
3. Qual a próxima entrega e de quem é?

Peça o dia e a hora. Sugira que o escritório digital prepare a pauta: "Direção, monta a pauta da reunião de segunda com o quadro de pedidos e os números".

## Passo 5. A regra de uso de IA da empresa

Monte uma regra de uma página, simples, para o dono aprovar e mostrar ao time. Explique o porquê em uma frase: hoje cada pessoa já usa a IA que quiser, e sem regra a empresa não sabe o que saiu, para onde foi e de quem é.

Cubra estes pontos, perguntando ao dono o que não estiver claro:
- **Onde se usa:** em qual conta e ferramenta (de preferência contas da empresa, não pessoais).
- **O que pode entrar:** que tipos de informação podem ser usados com IA.
- **O que nunca entra:** senha, dado pessoal de cliente, dado de saúde, contrato sigiloso e o que o item 8 do Cérebro proteger.
- **Quem aprova:** o que sai para cliente passa por quem.
- **De quem é:** o que for produzido com IA no trabalho é da empresa e fica guardado no projeto da empresa.
- **Onde não usar:** decisões sobre pessoas e respostas que exigem responsabilidade técnica continuam humanas.
- **Revisão:** a regra é revista a cada 90 dias.

Avise: isto é uma regra interna de boa prática, não um parecer jurídico. Para contrato de trabalho ou política formal, vale a revisão de um advogado.

## O arquivo PLANO-90.md

Gere para download (ou em bloco de código) e peça para adicionar ao projeto. Sugira imprimir a primeira página.

```markdown
# Plano de 90 dias · [Empresa]
De [segunda-feira de início] a [data final] · decidido por [dono] com [líder, ou "sem líder: o dono acompanha"]

## As prioridades
| # | Objetivo | Número hoje | Meta 90 dias (estimativa) | Onde se mede | Responsável |
|---|---|---|---|---|---|

## As ações
### Prioridade 1 · [nome]
| Tempo | Ação | Responsável | Data | Pronto quando |
|---|---|---|---|---|

## O que deixamos de fazer
- [ ]

## O ritual
Toda [dia], às [hora], 30 minutos: número, trava, próxima entrega.

## Número para medir em 30 dias
[o número escolhido e o valor de hoje]

## Regra de uso de IA da [Empresa]
[a regra de uma página]

## Encontro de acompanhamento
Online, duas semanas depois da imersão. Levar: o quadro de pedidos e o número de cada prioridade.
```

Feche perguntando ao dono e ao líder: "Os dois assinam embaixo deste plano?". Se o líder estiver junto, peça que ele diga em voz alta qual é a primeira ação dele e a data.
