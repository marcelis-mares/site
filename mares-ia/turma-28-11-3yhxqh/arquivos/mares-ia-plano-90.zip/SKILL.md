---
name: mares-ia-plano-90
description: Fecha o Plano de ação de 90 dias da empresa, com no máximo 3 prioridades, responsável com nome, prazo com data, número de antes e como medir, o que a empresa deixa de fazer, o ritual semanal de acompanhamento e a regra de uso de IA da empresa. Lê o Cérebro, o Diagnóstico, o Mapa e o Escritório e devolve PLANO-90.md. Use quando o usuário pedir "plano de 90 dias", "plano de ação", "regra de uso de IA", "política de IA da empresa" ou no Bloco 7 da Imersão Mares.IA.
---

# Plano de 90 dias · Imersão Mares.IA

## Como conduzir a conversa

Esta regra vale sobre qualquer outra desta skill. A pessoa é leiga: ela precisa saber sempre onde está, o que falta e o que vai receber. Conduza com firmeza e no tempo.

1. **Abra mostrando o caminho.** Na primeira mensagem, em até 5 linhas: o que vamos fazer, o tempo (cerca de 30 minutos), o que a pessoa recebe no fim (o arquivo **PLANO-90.md** na pasta mares.ia: as prioridades dos próximos 90 dias, cada uma com responsável, prazo e o número que vai medir, e a regra de uso de IA da empresa) e as etapas: 1) as prioridades · 2) as ações, os responsáveis e as datas · 3) a regra de uso de IA. Se já leu arquivos da pasta, diga o que leu e que vai pular o que já sabe.
2. **Rascunho primeiro, pergunta depois.** Sempre que os arquivos da pasta (DIAGNOSTICO.md, CEREBRO.md, MAPA.md e os outros) já derem a resposta, escreva a sua proposta e pergunte só se está certa, com opções: A) está certo · B) quero ajustar. Pergunte do zero só o que nenhum arquivo responde.
3. **Cada mensagem com pergunta segue o mesmo formato:** "Etapa X de Y · [nome da etapa]", uma frase de contexto (por que isso importa), e **no máximo 3 perguntas curtas e numeradas**, cada uma com opções para escolher (A, B, C, D, ou a ferramenta de pergunta com opções, se tiver) ou um exemplo de resposta. Diga: "Responda com o número e a letra, ou escreva do seu jeito."
4. **No máximo 3 mensagens com pergunta nesta skill.** Planeje as perguntas para caber nesse limite. Se a pessoa se alongar, resuma o que entendeu, diga "vou seguir para a próxima etapa" e siga.
5. **Resposta vaga merece uma pergunta a mais**, só uma, com opções. "Não sei" vale: marque o que faltou e siga.
6. **Entre uma etapa e outra**, uma linha só: o que ficou decidido e qual é a próxima etapa.

Plano bom é o que cabe na segunda-feira. Este bloco transforma as decisões do dia em compromisso com nome e data.

**A condição que vale o bloco inteiro:** a transformação acontece quando o dono conduz, não quando o dono delega. O dono decide prioridade e o que deixa de fazer. O líder assume a execução e o ritmo.

## Regras

1. **No máximo 3 prioridades.** Se o dono quiser mais, pergunte qual delas ele tiraria se tivesse que escolher. Nem tudo ao mesmo tempo.
2. **Toda ação tem nome e data.** "Comercial" não é responsável. "Ana, até 15/12" é.
3. **Toda prioridade tem um número.** O número de hoje (antes) e onde ele será medido. Se não existir, a primeira ação é medir.
4. **Datas reais.** Confira a data de hoje e conte os 90 dias a partir da próxima segunda-feira: o dia 90 é 89 dias depois do início. Avise se o período pega feriado ou fim de ano e ajuste os prazos dos primeiros 30 dias.
5. **Sem líder também funciona.** Se o dono veio sozinho e não tem líder, o dono acompanha e o responsável de cada ação é quem faz a tarefa.
6. **No máximo 3 perguntas por mensagem.** Proponha um rascunho completo primeiro e peça só as correções: é mais rápido do que perguntar item por item.

## O que ler primeiro

CEREBRO.md, DIAGNOSTICO.md, MAPA.md e ESCRITORIO.md, na pasta mares.ia. Use as frentes de "Fazer agora" do Mapa como ponto de partida. Mostre o que você leu e proponha um rascunho, em vez de perguntar do zero.

## Passo 1. As prioridades

Para cada prioridade (máximo 3):
- **Objetivo** em uma frase, ligado a uma frente do Mapa.
- **Número:** valor de hoje, meta em 90 dias (estimativa), onde se mede.
- **Responsável:** uma pessoa com nome.
- **Mesa do escritório** que ajuda, se houver.

## Passo 2. As ações em três tempos

| Tempo | Foco |
|---|---|
| Dias 1 a 30 | arrumar a base: medir, escrever o processo, testar com poucos casos |
| Dias 31 a 60 | rodar de verdade e corrigir |
| Dias 61 a 90 | consolidar, medir o resultado, decidir o próximo passo |

Cada ação tem: o que é, responsável, data e como se sabe que ficou pronta. No máximo 2 ações por prioridade em cada tempo. Na Imersão, detalhe os dias 1 a 30 e deixe uma linha só para cada um dos outros dois tempos.

## Passo 3. O que a empresa deixa de fazer

Pergunte ao dono: "Para caber isso, o que a empresa para de fazer, ou faz menos?". Registre pelo menos uma coisa. Sem isso, o plano disputa tempo com a rotina e perde.

## Passo 4. O ritual

Proponha uma reunião semanal de 30 minutos, sempre no mesmo dia e hora, com três perguntas:
1. O número de cada prioridade andou?
2. O que travou e quem destrava?
3. Qual a próxima entrega e de quem é?

Peça o dia e a hora. Sugira que o escritório digital prepare a pauta: "Direção, monta a pauta da reunião de segunda com o quadro de pedidos e os números".

## Passo 5. O tempo que a IA libera

Pergunte ao dono: "O que cada pessoa da sua empresa vai fazer com o tempo que a IA libera?". Para cada função que ganha tempo com as frentes do plano, registre o que a pessoa passa a fazer (atender melhor, vender mais, cuidar de um processo, aprender outra função). Se a resposta for "não sei", registre como decisão pendente para os primeiros 30 dias.

## Passo 6. A regra de uso de IA da empresa

Monte uma regra de uma página, simples, para o dono aprovar e mostrar ao time. Explique o porquê em uma frase: hoje cada pessoa já usa a IA que quiser, e sem regra a empresa não sabe o que saiu, para onde foi e de quem é.

Cubra estes pontos, perguntando ao dono o que não estiver claro:
- **Onde se usa:** em qual conta e ferramenta (de preferência contas da empresa, não pessoais).
- **O que pode entrar:** que tipos de informação podem ser usados com IA.
- **O que nunca entra:** senha, dado pessoal de cliente, dado de saúde, contrato sigiloso e o que a seção 9 do Cérebro (regras invioláveis) proteger.
- **Quem aprova:** o que sai para cliente passa por quem.
- **De quem é:** o que for produzido com IA no trabalho é da empresa e fica guardado na pasta da empresa, em conta da empresa.
- **Onde não usar:** decisões sobre pessoas e respostas que exigem responsabilidade técnica continuam humanas.
- **Revisão:** a regra é revista a cada 90 dias.

Avise: isto é uma regra interna de boa prática, não um parecer jurídico. Para contrato de trabalho ou política formal, vale a revisão de um advogado.

## O arquivo PLANO-90.md

Depois do "de acordo" do fechamento, grave o arquivo **PLANO-90.md** direto na pasta de trabalho (a pasta **mares.ia**, aberta na aba Code). Se a pessoa estiver em outra pasta, avise e peça para abrir a mares.ia. Sugira imprimir a primeira página.

```markdown
# Plano de 90 dias · [Empresa]
De [segunda-feira de início] a [data final] · decidido por [dono] com [líder, ou "sem líder: o dono acompanha"]

## As prioridades
| # | Objetivo | Número hoje | Meta 90 dias (estimativa) | Onde se mede | Responsável |
|---|---|---|---|---|---|

## As ações
### Prioridade 1 · [nome]
| Tempo | Ação | Responsável | Data | Pronto quando |
|---|---|---|---|---|

## O que deixamos de fazer
- [ ]

## O tempo que a IA libera
| Função | Tempo que ganha (estimativa) | O que passa a fazer |
|---|---|---|

## O ritual
Toda [dia], às [hora], 30 minutos: número, trava, próxima entrega.

## Número para medir em 30 dias
[o número escolhido e o valor de hoje]

## Regra de uso de IA da [Empresa]
[a regra de uma página]

## Encontro de acompanhamento
Online, duas semanas depois da imersão. Levar: o quadro de pedidos e o número de cada prioridade.
```

Depois do "de acordo", se o líder estiver junto, peça que ele diga a primeira ação dele e a data.

## Guardar a rodada anterior (histórico)

A skill nunca muda com o uso; o que muda é o resultado de cada rodada, salvo na pasta mares.ia. Para não perder a rodada anterior:

1. **Antes do "Está de acordo?" do fechamento, veja se já existe** o **PLANO-90.md** na pasta mares.ia.
2. Se existir, veja de qual empresa é: o nome está no título do arquivo, na primeira linha (no site, no `<title>` da página; na minha-marca, no nome da empresa dentro dela).
   - Se for a mesma empresa, avise em uma linha: "Já existe uma versão de [data]. Vou guardar essa no histórico e salvar a nova no lugar."
   - Se for outra empresa, pare e não mexa em nada. Não diga o nome da outra empresa. Diga: "Esta pasta já tem o plano de 90 dias de outra empresa. Cada empresa precisa da sua própria pasta mares.ia, para os dados não se misturarem. Abra a pasta certa, ou crie uma nova, e me avise." Só salve depois que a pessoa estiver na pasta certa.
3. **Guarde a anterior** na subpasta **historico** da mares.ia (crie se não existir), com a data dela na frente do nome: por exemplo `historico/2026-11-28_PLANO-90.md`. A data é a que estiver escrita no topo do arquivo; se não houver, use a data em que ele foi salvo. Nunca apague a versão anterior.
4. **Salve a nova com o nome de sempre**, sem data, porque é esse nome que as outras skills leem.
5. Compare com o plano anterior: o que foi cumprido, o que ficou para trás e o número de antes e de agora.

## Fechamento: a pessoa aprova antes de guardar

Esta regra vale sobre qualquer outra desta skill.

Quando o trabalho estiver pronto, não guarde direto como versão final:

1. Antes de mostrar o resumo final, siga a seção "Guardar a rodada anterior (histórico)": veja se o arquivo já existe na pasta e, se for de outra empresa, siga o que está lá antes de continuar. Assim você já sabe o nome e o lugar do arquivo. Depois mostre o resultado final em poucas linhas: o que vai ficar guardado e onde.
2. Pergunte, com estas palavras: **"Finalizamos aqui. Esta é a versão final. Está de acordo?"**, com as opções A) Estou de acordo, pode guardar · B) Quero ajustar alguma coisa. Se tiver a ferramenta de pergunta com opções, use-a.
3. Se a resposta for B, ajuste o que a pessoa pedir, uma coisa por vez, e pergunte de novo.
4. Só depois do "de acordo", salve o arquivo como versão final e diga em uma linha onde ele ficou guardado. A última frase, depois de gravar, é esta: Agora o próximo passo é o encontro de acompanhamento online, no sábado 12/12 às 9h35. Traga o plano e o número que você está medindo.

Se a skill precisou salvar um rascunho antes, para a pessoa ver (por exemplo, a página aberta no navegador), ele continua sendo rascunho até o "de acordo".
