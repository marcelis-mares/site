---
name: mares-ia-site-completo
description: Planeja e constrói o site completo da empresa, com várias páginas, na arquitetura que a MARES usa no próprio site (maresconsultoria.com.br): home, sobre, serviços com página própria, porta de entrada comercial, isca gratuita, blog, contato, privacidade e página de obrigado, já com SEO, dados estruturados, texto pronto para ser citado por buscadores de IA, imagem de compartilhamento por página, aviso de cookies e medição de cada botão. Lê o Cérebro e a marca da pasta mares.ia, entrega os arquivos prontos para GitHub e Vercel e confere tudo antes de publicar. Use quando o usuário pedir "site completo", "site com várias páginas", "arquitetura do site", "terminar o meu site", "site que aparece no Google", "refazer o meu site" ou quando a página de demonstração da skill mares-ia-site já não bastar.
---

# Site completo · arquitetura MARES

## Como conduzir a conversa

Esta regra vale sobre qualquer outra desta skill. A pessoa é leiga: ela precisa saber sempre onde está, o que falta e o que vai receber. Conduza com firmeza e no tempo.

1. **Abra mostrando o caminho.** Na primeira mensagem, em até 5 linhas: o que vamos fazer, o tempo (mais de uma conversa), o que a pessoa recebe no fim (o site da empresa na pasta **site** dentro da mares.ia, com as páginas aprovadas, e o arquivo **SITE.md** com o que ficou pronto e o que falta) e as etapas: 1) o mapa do site · 2) uma página de cada vez · 3) a medição · 4) a conferência · 5) a publicação. Se já leu arquivos da pasta, diga o que leu e que vai pular o que já sabe.
2. **Rascunho primeiro, pergunta depois.** Sempre que os arquivos da pasta (DIAGNOSTICO.md, CEREBRO.md, MAPA.md e os outros) já derem a resposta, escreva a sua proposta e pergunte só se está certa, com opções: A) está certo · B) quero ajustar. Pergunte do zero só o que nenhum arquivo responde.
3. **Cada mensagem com pergunta segue o mesmo formato:** "Etapa X de Y · [nome da etapa]", uma frase de contexto (por que isso importa), e **no máximo 3 perguntas curtas e numeradas**, cada uma com opções para escolher (A, B, C, D, ou a ferramenta de pergunta com opções, se tiver) ou um exemplo de resposta. Diga: "Responda com o número e a letra, ou escreva do seu jeito."
4. **No máximo 8 mensagens com pergunta nesta skill.** Planeje as perguntas para caber nesse limite. Se a pessoa se alongar, resuma o que entendeu, diga "vou seguir para a próxima etapa" e siga.
5. **Resposta vaga merece uma pergunta a mais**, só uma, com opções. "Não sei" vale: marque o que faltou e siga.
6. **Entre uma etapa e outra**, uma linha só: o que ficou decidido e qual é a próxima etapa.

Você vai planejar e construir o site da empresa de quem está falando com você, no mesmo desenho que a MARES usa no próprio site. A pessoa é dona ou líder de empresa e quase sempre leiga em tecnologia: cada passo é explicado em palavras simples, e quem aprova o texto é ela.

A diferença para a skill `mares-ia-site`: aquela faz **uma página de demonstração** em minutos. Esta faz **o site de verdade**, com várias páginas, pensado para ser achado no Google e nas buscas por IA e para medir o que acontece em cada botão. Leva mais de uma conversa. Se a pessoa só quer ver como se faz, use a outra.

## Regra zero

**Site é a empresa falando em público.** Nada vai ao ar sem o dono ler cada página inteira e aprovar. Nunca invente número, cliente, depoimento, prêmio, endereço, ano de fundação ou nota de avaliação. Onde faltar, escreva `[PREENCHER]` e mostre a lista do que falta no fim.

## Antes de começar: o que ler

1. **CEREBRO.md** da pasta mares.ia: oferta, cliente nas palavras dele, provas que podem ser citadas, perguntas frequentes, regras invioláveis.
2. A skill **minha-marca** (se existir): voz, ideia central, cores e fontes.
3. **BENCHMARK.md** ou `benchmark-*.md` (se existir): o que o mercado não faz e o que o cliente reclama dos concorrentes. Use para afiar a promessa, sem citar concorrente pelo nome.
4. **SEO.md** (se existir, feito pela skill `mares-ia-seo`): os termos que o cliente procura e os problemas do site atual.
5. O site atual da empresa, se houver: leia as páginas para não perder o que já funciona.

Sem Cérebro, pare e sugira rodar primeiro a `mares-ia-cerebro`. Site sem Cérebro sai genérico.

## Setores com regra própria

Se a empresa for de **saúde** (medicina, odontologia, psicologia, nutrição, fisioterapia, estética), **advocacia**, **contabilidade** ou outra profissão com conselho, avise antes de escrever: o conselho da profissão tem regras de publicidade (por exemplo, o que pode sobre antes e depois, promessa de resultado, preço e título de especialista). Peça à pessoa para confirmar com o conselho ou o responsável técnico o que pode entrar, e não escreva promessa de resultado de tratamento. Na dúvida, deixe o trecho marcado `[CONFERIR COM O CONSELHO]`.

## Passo 1. A arquitetura (uma conversa, cerca de 15 minutos)

Mostre o mapa do site em uma tabela, a partir do Cérebro, e peça a aprovação antes de escrever qualquer página. O desenho padrão, o mesmo do site da MARES, é:

| Página | Endereço | Para que existe |
|---|---|---|
| Home | `/` | Dizer em 5 segundos o que a empresa resolve e para quem, e levar para a porta de entrada |
| Sobre | `/sobre/` | Quem está por trás, a virada que explica por que a empresa existe, o jeito de trabalhar |
| Serviços | `/servicos/` | Todos os serviços em cartões; o serviço principal leva para página própria |
| Página de cada serviço principal | `/nome-do-servico/` | Vender um serviço só: para quem é, o que recebe, como funciona, perguntas, botão |
| Porta de entrada | `/agendar/` ou `/diagnostico/` | A página comercial central: o primeiro passo que a empresa pede ao cliente (conversa, avaliação, consulta, orçamento) |
| Isca gratuita (opcional) | `/teste/` ou `/guia/` | Algo de valor, de graça, que traz contato: teste rápido, checklist, guia. Só se a pessoa tiver o conteúdo |
| Blog (opcional) | `/blog/` | Artigos que respondem às perguntas que o cliente digita no Google |
| Contato | `/contato/` | WhatsApp, endereço, mapa, horário |
| Política de privacidade | `/politica-de-privacidade/` | Obrigatória se o site tiver formulário ou medição |
| Obrigado | `/obrigado/` | Depois de um contato: confirma, diz o próximo passo. Fica fora do Google (`noindex`) |

Regras do mapa:
- **Uma porta de entrada só.** Todas as páginas apontam para o mesmo primeiro passo. Duas portas dividem o cliente.
- **Página própria só para serviço que vende sozinho.** O resto fica em cartão na página de Serviços.
- **Começar pequeno:** Home, Sobre, Serviços, Porta de entrada, Contato e Privacidade. Blog e isca entram quando houver conteúdo de verdade.
- Se a empresa for local (clínica, loja, escritório), a cidade e o bairro aparecem no título da Home, no Contato e nos dados estruturados.

## Passo 2. O que toda página tem

Escreva cada página nesta ordem, encurtando o que não tiver conteúdo:

1. **Menu fixo no topo**, igual em todas as páginas, com o botão da porta de entrada em destaque na cor principal. No celular, o menu vira um botão de três linhas.
2. **Título** com o resultado que o cliente quer, nas palavras dele.
3. **Resposta direta:** logo abaixo do título, um parágrafo de 2 a 3 linhas, factual, que responde o que a empresa é e do que a página trata. É o trecho que o Google e os buscadores de IA (ChatGPT, Gemini, Perplexity, Copilot) copiam para responder. Classe `resposta-direta`. É o primeiro lugar a atualizar quando algo da empresa mudar.
4. O corpo da página (para quem é, o que recebe, como funciona, provas, quem somos).
5. **Perguntas frequentes visíveis na tela**, quando o Cérebro tiver. As mesmas perguntas e respostas entram nos dados estruturados. Pergunta que só está no código e não aparece na tela é proibida pelo Google.
6. **Chamada final com dois botões:** o da porta de entrada, cheio, na cor principal; e um secundário, contornado (por exemplo, "Conhecer os serviços" ou "Falar no WhatsApp").
7. **Rodapé** com nome, cidade, WhatsApp, redes, link da privacidade e o ano.

Ritmo visual: alterne fundo claro e fundo escuro ou de cor suave entre as seções. Duas seções seguidas da mesma cor parecem uma só, e o leitor acha que a página acabou.

## Passo 3. SEO de cada página (sem isso a página não está pronta)

- `<title>` com **até 60 caracteres**, a informação decisiva na frente, o nome da empresa no fim.
- `<meta name="description">` com **até 155 caracteres**, dizendo o que a pessoa encontra e o motivo para clicar.
- Um `<h1>` só por página. Os subtítulos em `<h2>` e `<h3>`, na ordem.
- `<link rel="canonical">` com o endereço completo e definitivo da página, com a barra no fim.
- `<meta name="viewport" content="width=device-width, initial-scale=1">` e `<html lang="pt-BR">`.
- Imagens com `alt` descrevendo o que mostram, em tamanho de web (até cerca de 200 KB), com nome simples sem espaço nem acento.
- Links internos entre as páginas, sempre no formato absoluto `/servicos/`.
- **Dados estruturados (JSON-LD)**, um bloco por página, com os itens ligados por `@id`:
  - todas as páginas: `Organization` (ou `LocalBusiness`, `MedicalClinic`, `ProfessionalService`, conforme o negócio) e `WebSite`;
  - páginas internas: `BreadcrumbList`;
  - Serviços: `Service` com o catálogo;
  - página com perguntas visíveis: `FAQPage`;
  - artigo do blog: `Article` com autor e a fonte do dado citado.
  - **Nunca** colocar `Review` ou nota dada pela própria empresa, nem endereço, cidade ou ano que a pessoa não confirmou.
- **Imagem de compartilhamento por página** (1200 por 630, nas cores da marca, com a frase da página): é o que aparece quando o link vai para o WhatsApp, o LinkedIn ou o Facebook. Declarar `og:title`, `og:description`, `og:image`, `og:image:width`, `og:image:height`, `og:image:alt` e `twitter:card`. Sem isso, todo link mostra a mesma capa.

Arquivos da raiz do site:
- `sitemap.xml` com todas as páginas públicas e a data de cada uma. Página com `noindex` fica fora.
- `robots.txt` liberando o site e apontando o sitemap. Páginas internas (obrigado, ferramentas) bloqueadas.
- `llms.txt`: um texto curto que explica aos buscadores de IA o que a empresa é, quais páginas importam e quais números podem ser citados, com fonte.

## Passo 4. Medição (página nova só está pronta quando mede)

Pergunte se a pessoa já tem **Google Analytics 4** (um código que começa com `G-`). Se não tiver, o site vai ao ar sem medição e a criação do Analytics vira tarefa da lista final. Nunca invente um código.

Com o código:
1. **Aviso de cookies** num arquivo único `cookies.js`, carregado por todas as páginas: botões "Aceitar" e "Só o essencial", escolha guardada no navegador. Use o **modo de consentimento do Google**: o Analytics carrega com o armazenamento negado e só grava cookie depois do Aceitar. Assim a contagem de visitas não some e quem recusa fica protegido.
2. No mesmo `cookies.js`, uma função `evento(nome, params)` e a escuta, em todas as páginas, destes cliques:

| Evento | Quando |
|---|---|
| `clique_whatsapp` | link para `wa.me` ou `api.whatsapp.com`, com o texto do botão |
| `clique_agendar` | botão da porta de entrada |
| `clique_telefone` | link `tel:` |
| `clique_email` | link `mailto:` |
| `clique_social` | Instagram, LinkedIn, YouTube, Facebook, TikTok |
| `baixar_arquivo` | link para pdf, xlsx, zip, docx |
| `gerar_lead` | formulário enviado com sucesso (se houver formulário) |

3. Nunca repetir a mesma escuta em outro arquivo: o evento aparece em dobro no relatório.
4. Avise: no Analytics, o evento só pode ser marcado como **evento principal** (conversão) depois que aparecer na lista, o que leva até 24 horas. Fica para o dia seguinte.

Pixel de anúncio (Meta, Google Ads) só entra se a pessoa pedir e se passar pelo mesmo aviso de cookies.

Formulário: por padrão, **sem formulário**. O contato é o botão de WhatsApp, com mensagem pronta no formato `https://wa.me/55DDDNUMERO?text=` (confirme o número com a pessoa). Se ela quiser formulário, explique que é preciso um lugar para receber os dados (um serviço de formulário, uma planilha, um CRM) e a política de privacidade dizendo o que se faz com eles. Não monte formulário que grave dado sem destino combinado.

## Passo 5. Construir

- Uma pasta `site` dentro da mares.ia, com uma pasta por página, cada uma com o seu `index.html`, mais `styles.css`, `cookies.js`, `sitemap.xml`, `robots.txt`, `llms.txt` e a pasta `img`.
- Um `styles.css` para todas as páginas. Cores e fontes da marca. Celular primeiro: texto legível, botões grandes, nada estourando a tela.
- Sem bibliotecas externas obrigatórias. Fontes do Google Fonts podem entrar, ou hospedadas na pasta `fonts`.
- Escreva e mostre **uma página de cada vez**, começando pela Home. Peça no máximo duas rodadas de ajuste por página. Depois da Home aprovada, as outras seguem o mesmo visual.

## Passo 6. Conferir antes de publicar

Rode esta lista e mostre o resultado em tabela, página por página, com "ok" ou o que falta:

- [ ] título até 60 e descrição até 155 caracteres
- [ ] um h1, canonical, viewport, lang
- [ ] resposta direta abaixo do título
- [ ] perguntas do FAQPage visíveis na tela
- [ ] JSON-LD sem erro (testar depois em search.google.com/test/rich-results)
- [ ] imagem de compartilhamento própria
- [ ] todas as imagens com alt e leves
- [ ] botão de WhatsApp com o número confirmado
- [ ] `cookies.js` carregado e eventos funcionando (se houver Analytics)
- [ ] links internos funcionando, nenhum link quebrado
- [ ] página na sitemap (ou com noindex, se for interna)
- [ ] nenhum `[PREENCHER]` ou `[CONFERIR COM O CONSELHO]` sobrando
- [ ] o dono leu a página inteira e aprovou

## Passo 7. Publicar

GitHub guarda, Vercel coloca no ar, nos mesmos passos da skill `mares-ia-site`, com uma diferença: em vez de arrastar um arquivo, a pessoa arrasta **o conteúdo da pasta `site`** (as pastas e os arquivos de dentro, não a pasta `site` em si) para o quadro do GitHub.

Avise, com estas palavras:
- **O plano grátis da Vercel (Hobby) é para uso pessoal, sem fim comercial.** Para o site definitivo de uma empresa, compare com a equipe de TI ou com o Claude onde publicar (segurança, custo, se o plano permite uso comercial). Não escolha pela pessoa.
- **Domínio próprio** (www.suaempresa.com.br) tem custo de registro e é um passo à parte.
- Depois de publicado: cadastrar o site no **Google Search Console** e no **Bing Webmaster Tools** (o Copilot só cita o que está no índice do Bing) e enviar o sitemap nos dois.
- Empresa com endereço físico: criar ou revisar o **Perfil da Empresa no Google** (o antigo Google Meu Negócio), com o link do site. Para negócio local, é o que mais traz cliente pelo Google.

## No fim

Salve na pasta mares.ia um `SITE.md` com: o mapa aprovado, o que ficou pronto, o que falta (`[PREENCHER]`, Analytics, domínio, Search Console, Perfil da Empresa) e a data. Diga em uma linha onde cada arquivo ficou.

Regras de escrita: português do Brasil, sem travessão, linguagem do cliente e não da tecnologia, no máximo 3 frases por parágrafo nas páginas.

## Guardar a rodada anterior (histórico)

A skill nunca muda com o uso; o que muda é o resultado de cada rodada, salvo na pasta mares.ia. Para não perder a rodada anterior:

1. **Antes do "Está de acordo?" do fechamento, veja se já existe** a pasta **site** e o **SITE.md** na pasta mares.ia.
2. Se existir, veja de qual empresa é: o nome está no título do arquivo, na primeira linha (no site, no `<title>` da página; na minha-marca, no nome da empresa dentro dela).
   - Se for a mesma empresa, avise em uma linha: "Já existe uma versão de [data]. Vou guardar essa no histórico e salvar a nova no lugar."
   - Se for outra empresa, pare e não mexa em nada. Não diga o nome da outra empresa. Diga: "Esta pasta já tem o site de outra empresa. Cada empresa precisa da sua própria pasta mares.ia, para os dados não se misturarem. Abra a pasta certa, ou crie uma nova, e me avise." Só salve depois que a pessoa estiver na pasta certa.
3. **Guarde a anterior** na subpasta **historico** da mares.ia (crie se não existir), com a data dela na frente do nome: por exemplo `historico/2026-11-28_SITE.md`. A data é a que estiver escrita no topo do arquivo; se não houver, use a data em que ele foi salvo. Nunca apague a versão anterior.
4. **Salve a nova com o nome de sempre**, sem data, porque é esse nome que as outras skills leem.
5. Diga quais páginas mudaram.

## Fechamento: a pessoa aprova antes de guardar

Esta regra vale sobre qualquer outra desta skill.

Quando o trabalho estiver pronto, não guarde direto como versão final:

1. Antes de mostrar o resumo final, siga a seção "Guardar a rodada anterior (histórico)": veja se o arquivo já existe na pasta e, se for de outra empresa, siga o que está lá antes de continuar. Assim você já sabe o nome e o lugar do arquivo. Depois mostre o resultado final em poucas linhas: o que vai ficar guardado e onde.
2. Pergunte, com estas palavras: **"Finalizamos aqui. Esta é a versão final. Está de acordo?"**, com as opções A) Estou de acordo, pode guardar · B) Quero ajustar alguma coisa. Se tiver a ferramenta de pergunta com opções, use-a.
3. Se a resposta for B, ajuste o que a pessoa pedir, uma coisa por vez, e pergunte de novo.
4. Só depois do "de acordo", salve o arquivo como versão final e diga em uma linha onde ele ficou guardado. Depois, feche com o próximo passo: "O próximo passo é cadastrar o site no Google Search Console e no Bing Webmaster Tools e, se a empresa atende numa cidade, revisar o Perfil da Empresa no Google."

Se a skill precisou salvar um rascunho antes, para a pessoa ver (por exemplo, a página aberta no navegador), ele continua sendo rascunho até o "de acordo".
