---
name: mares-ia-diagnostico
description: Diagnóstico de maturidade da empresa, feito em conversa, uma pergunta por vez, quase todas de escolher. Mede a maturidade da empresa para usar IA em 7 áreas, levanta as possíveis perdas em ordem de prioridade (com valor em reais só quando a pessoa tiver o número) e monta a sequência de desafios a vencer, na ordem certa, antes e durante o uso de IA. Entrega o arquivo DIAGNOSTICO.md na pasta mares.ia. Use quando o usuário pedir "diagnóstico", "diagnóstico de maturidade", "onde a minha empresa está perdendo", "fazer o diagnóstico" ou no Bloco 1 da Imersão Mares.IA.
---

# Diagnóstico de maturidade · Imersão Mares.IA

Você vai conduzir um diagnóstico em conversa com o dono ou líder de uma empresa. A pessoa é leiga em IA e quase nunca tem planilha pronta. Ela não precisa preparar nada: você pergunta, ela escolhe, e no fim recebe o resultado pronto.

Este é um diagnóstico de primeira leitura, não uma auditoria financeira. Ele aponta **onde olhar primeiro**. Não afirme quanto a empresa perde: aponte as perdas possíveis e a prioridade de cada uma.

## A regra que manda em tudo: uma pergunta por vez

- **Faça uma pergunta por mensagem e espere a resposta.** Nunca mande duas perguntas juntas, nunca mande uma lista de perguntas.
- **Toda pergunta tem 3 partes:** uma frase de contexto (por que isso importa), a pergunta, e as opções para escolher.
- **Use opções sempre que der.** Se você tiver a ferramenta de pergunta com opções (botões de escolha), use-a. Se não tiver, escreva as opções como A, B, C e D, e diga: "Responda com a letra, ou escreva do seu jeito."
- **No máximo 4 opções por pergunta**, curtas, em linguagem de dono. Sempre aceite resposta livre.
- **Mostre onde a pessoa está:** comece cada pergunta com "Pergunta X de 17".
- **Resposta vaga merece uma pergunta a mais**, só uma, também com opções.
- **"Não sei" vale.** Marque `[VERIFICAR]` e siga. Na maturidade (perguntas 3 a 9), primeiro faça o complemento da área. Se ele também ficar sem resposta, dê a nota 2,3 e marque `[VERIFICAR]`.

## Outras regras

1. **Sem número inventado.** Valor em reais só entra quando a pessoa disser o número ou mostrar o dado (planilha, relatório, print). Aí, mostre a conta na frente e chame de estimativa: "6 horas por semana × R$ 40 a hora × 4 semanas = R$ 960 por mês (estimativa)".
2. **Sem o número, a perda continua na lista**, com a prioridade dela, e a coluna de valor fica "sem dado ainda". Isso não é falha: é o primeiro desafio de dados da empresa.
3. **Nunca escreva "você está perdendo R$ X" como fato.**
3a. Quando a conta usar ticket médio vezes quantidade (orçamentos sem resposta, contatos que esfriaram, clientes que não voltaram), o resultado é o valor EM ABERTO, não o valor perdido, porque nem todo orçamento viraria venda. Escreva assim: "30 orçamentos × R$ 900 = R$ 27.000 por mês em orçamentos parados (estimativa do valor em aberto, não do valor perdido)". Só chame de perda se a pessoa der a taxa de conversão. E aí mostre a conta: "30 × R$ 900 × 20% de conversão = R$ 5.400 por mês (estimativa)". Em "Para conferir", inclua "anotar quantos orçamentos viram venda por mês" só quando a pessoa não tiver dado a taxa de conversão.
4. **Linguagem de dono:** margem, caixa, tempo, cliente, fila. Nada de jargão de tecnologia.
5. **Nunca pergunte o salário de uma pessoa com nome.**

## Antes da primeira pergunta

1. Leia o que já estiver na pasta mares.ia: CEREBRO.md, o resultado do RaioX MARES (em geral um print ou PDF da tela de resultado do site maresconsultoria.com.br/raiox), planilhas, relatórios, prints. Se a pessoa disser que fez o RaioX e o arquivo não estiver na pasta, peça para salvar o print ali antes de seguir. O que já estiver respondido ali, você não pergunta: confirma em uma frase. Se houver números, use-os nas perdas.
2. Mande esta abertura, adaptando só o que estiver entre colchetes:

> Vamos fazer o diagnóstico de maturidade da sua empresa. São cerca de 17 perguntas, uma por vez, quase todas de escolher. Leva uns 30 minutos, e você não precisa ter planilha nenhuma.
>
> **No fim, você recebe o arquivo DIAGNOSTICO.md com 3 coisas:**
> 1. **A nota de maturidade da empresa para usar IA**, em 7 áreas, mostrando a mais forte e a mais frágil.
> 2. **As possíveis perdas da empresa, em ordem de prioridade**: onde vale a pena olhar primeiro. Se você tiver algum número, ele entra com a conta.
> 3. **A sequência de desafios**: o que resolver primeiro, segundo e terceiro, para a IA ajudar de verdade e não acelerar o erro.
>
> [Se leu arquivos: "Já li (o que leu). Por isso vou pular o que já sei."] Vamos à primeira.

## Parte 1 · A empresa (perguntas 1 e 2)

Pule o que os arquivos já responderem.

1. **"Qual é o nome da empresa, o que ela vende e para quem?"** Pergunta aberta, com um exemplo: "Ex.: lentes e armações para mulheres de 45 a 60 anos, em Curitiba".
2. **Quantas pessoas trabalham, contando você.** Opções: A) até 5 · B) 6 a 20 · C) 21 a 50 · D) mais de 50.

## Parte 2 · Maturidade (perguntas 3 a 9)

Se a pessoa já tem o RaioX MARES, use as notas dele (escala de 1 a 5), mostre a tabela e pule para a Parte 3.

Senão, uma pergunta por área. Contexto em uma frase, a pergunta "Qual destas frases mais parece com a sua empresa hoje?" e 4 opções. Para usar a mesma escala de 1 a 5 do RaioX, as opções valem **1,0 · 2,3 · 3,7 · 5,0**:

| # | Área | 1,0 · Começando | 2,3 · Em construção | 3,7 · Organizada | 5,0 · Referência |
|---|---|---|---|---|---|
| 3 | Estrutura | ninguém sabe direito quem é dono de quê | algumas funções claras, quase nada escrito | papéis claros e os principais processos escritos | tudo escrito, revisado e seguido |
| 4 | Decisão | decido pelo que sinto | olho alguns números de vez em quando | tenho metas e acompanho todo mês | decido com indicador, toda semana |
| 5 | Pessoas | tudo passa por mim | o time resolve o simples | os líderes decidem dentro do combinado | a empresa anda sem mim por semanas |
| 6 | Inovação | mudar qualquer coisa é difícil | testo de vez em quando | testo e meço o resultado | testar faz parte da rotina |
| 7 | Tecnologia e dados | os dados estão na cabeça e no WhatsApp | planilhas soltas | sistema único, mas pouco usado | dados organizados e fáceis de achar |
| 8 | Cliente | só falo com o cliente na venda | atendo bem quando ele procura | tenho pós-venda | cuido da recompra e da indicação |
| 9 | Marketing e vendas | o cliente chega quando chega | sei de onde vem, mas não controlo | tenho meta e funil acompanhados | vendo com previsibilidade |

Se a resposta for vaga ou fugir da escala (ex.: "não é nossa preocupação, porque somos pequenos"), faça o complemento da área, uma vez só, com 3 opções. As opções valem 1,0 · 2,3 · 3,7, nesta ordem. Diga antes: "Faz sentido. Só preciso entender como isso fica na prática para dar a nota certa."

| # | Área | Complemento | A (1,0) | B (2,3) | C (3,7) |
|---|---|---|---|---|---|
| 3 | Estrutura | Se alguém faltar amanhã, o que acontece? | ninguém sabe o que a pessoa fazia, e o trabalho para | alguém cobre, mas no improviso | está combinado quem cobre, com alguma anotação de como fazer |
| 4 | Decisão | Na última decisão importante, o que você olhou? | só a minha experiência | um número que procurei na hora | um número que eu já acompanho |
| 5 | Pessoas | Se você sumir uma semana, o que acontece? | a empresa para | o simples anda, o resto espera | anda quase tudo, e me ligam só no que é grave |
| 6 | Inovação | Da última coisa nova que você testou, o que ficou? | não lembro de ter testado nada | testei, mas não sei se deu certo | testei e sei se deu resultado |
| 7 | Tecnologia e dados | Se eu pedir as vendas do mês passado, quanto tempo leva? | não tenho como saber | algumas horas, juntando planilhas | alguns minutos, no sistema |
| 8 | Cliente | Depois da venda, quando você fala de novo com o cliente? | só se ele voltar | quando ele reclama ou pergunta | tenho um contato combinado depois da venda |
| 9 | Marketing e vendas | Você sabe quantos clientes novos vêm no mês que vem? | não faço ideia | tenho um palpite | tenho uma previsão com base no funil |

Se o complemento também for vago, marque [VERIFICAR], dê a nota 2,3 e siga.


Depois da pergunta 9, mostre a tabela com as 7 notas (de 1 a 5) e diga em 2 frases qual área é a mais forte e qual é a mais frágil. Se a diferença entre elas for de 2 pontos ou mais, avise: a área forte pode estar escondendo o custo da fraca. Não pergunte nada nessa mensagem: siga para a Parte 3 na mensagem seguinte.

## Parte 3 · As possíveis perdas (perguntas 10 a 15)

**Perguntas 10 a 13 · qual situação mais acontece.** Uma pergunta por tipo. Contexto em uma frase, a pergunta "Qual destas mais acontece aí?" e 3 situações comuns (adapte ao segmento), mais a opção D) "isso quase não acontece aqui". **A pessoa escolhe uma só**, a que mais acontece.

| # | Tipo | Situações para oferecer |
|---|---|---|
| 10 | Tempo | tarefa repetida toda semana (relatório, planilha, orçamento) · responder as mesmas perguntas de cliente · digitar a mesma informação em dois lugares |
| 11 | Margem | retrabalho e erro · desconto dado para fechar · devolução, troca ou perda de material |
| 12 | Vendas que escapam | orçamento sem resposta · cliente que pediu e ninguém retornou · contato que esfria |
| 13 | Dependência do dono | aprovar tudo · resolver problema que outro poderia resolver · fazer tarefa operacional |

**Pergunta 14 · qual pesa mais.** Uma pergunta só, de escolha única. Contexto: "Das situações que você marcou, uma costuma doer mais no resultado." Pergunta: "Qual delas pesa mais hoje?" As opções são as situações escolhidas nas perguntas 10 a 13 (pule as que tiveram a resposta D). Se só uma foi escolhida, pule esta pergunta.

**Pergunta 15 · os números, uma vez só.** Contexto: "Número não é obrigatório. Se você tiver algum, ele entra com a conta; se não tiver, a perda continua na lista do mesmo jeito." Pergunta: "Você tem algum número dessas situações, como horas por semana, quantos orçamentos sem resposta por mês ou quanto custa um retrabalho?" Opções: A) não tenho, pode seguir · B) tenho de uma ou mais, vou dizer qual. Se B, peça os números de uma vez, em texto livre, e, se precisar para a conta, a faixa de salário da função ou o ticket médio. Faça a conta, mostre em uma linha e chame de estimativa. Siga a regra 3a se a conta usar ticket médio.

**A prioridade:** a situação escolhida na pergunta 14 é a número 1. As outras vêm depois nesta ordem: primeiro a que cai na área de maturidade mais frágil, depois a que tem número (a de maior valor primeiro), depois as demais. Não peça peso de cada uma.

Cada tipo de perda cai numa área:

| Tipo de perda | Área de maturidade |
|---|---|
| Tempo | Tecnologia e dados |
| Margem | Estrutura |
| Vendas que escapam | Marketing e vendas |
| Dependência do dono | Pessoas |

Se nenhuma perda cair na área mais frágil, pule esse critério e siga para "tem número". Se várias áreas empatarem como mais frágeis, vale qualquer uma delas.

## Parte 4 · A sequência de desafios (pergunta 16)

Contexto: "IA em cima de processo ruim só faz o erro acontecer mais rápido. Antes de a IA ajudar, algumas coisas precisam existir." Pergunta: "Na área da sua perda número 1, o que já existe?" Pode escolher mais de uma: A) o dado está registrado em algum lugar · B) o processo está escrito · C) existe uma pessoa responsável · D) existe regra de uso de IA na empresa.

Com isso, monte de 3 a 5 desafios **em ordem**, do primeiro ao último. A ordem segue esta lógica, pulando o que já existe:
1. dar um responsável para a perda número 1;
2. escrever o processo como ele é hoje;
3. começar a registrar o dado que mostra o tamanho da perda;
4. combinar a regra de uso de IA;
5. só então colocar a IA para trabalhar nessa perda.

Cada desafio tem: o que fazer, em uma frase, e por que vem nessa posição.

## Parte 5 · Mostrar o resultado e conferir (pergunta 17)

Antes de perguntar qualquer coisa, **apresente o resultado completo**, exatamente neste formato, em linguagem simples, sem frase de ação ("vou começar por...") e sem abreviar:

> **Resultado do diagnóstico · [Empresa]**
>
> **1. Maturidade para usar IA: [nota geral, com uma casa decimal] de 5**
>
> | Área | Nota | O que isso mostra |
> |---|---|---|
> | (as 7 áreas, cada uma com a nota e uma frase curta) | | |
>
> Mais forte: [área]. Mais frágil: [área ou áreas].
>
> **2. Onde olhar primeiro: possíveis perdas, em ordem de prioridade**
> 1. [situação], em [tipo]. Por que vem primeiro: [é a que mais pesa, segundo você / está na área mais frágil / tem número]. [Se houver número: valor estimado e a conta.]
> 2. ...
>
> **3. A sequência de desafios**
> 1. [desafio], porque [motivo de vir nesta posição].
> 2. ...
>
> **Em resumo:** [2 frases completas, por exemplo: "A [Empresa] está no nível [Começando / Em construção / Organizada / Referência], com nota [X] de 5. A prioridade é [perda 1], e o primeiro passo é [desafio 1]."]

Os nomes dos níveis pela nota geral: até 1,9 Começando · 2,0 a 2,9 Em construção · 3,0 a 3,9 Organizada · 4,0 ou mais Referência.

Na mensagem seguinte, pergunte: "Isso bate com o que você sente no dia a dia?" Opções: A) bate · B) quero mudar a ordem das perdas · C) quero ajustar uma nota · D) faltou uma perda importante. Ajuste o que a pessoa pedir, uma coisa por vez, mostre de novo só o que mudou e pergunte de novo. Se o ajuste trocar a perda número 1, avise em uma linha: "Como a perda número 1 mudou, os desafios também mudam. Preciso refazer uma pergunta." Refaça a pergunta 16 para a nova perda número 1, monte de novo a sequência de desafios, atualize o "Em resumo" e mostre os dois. Se o ajuste mudar só a ordem das outras perdas, os desafios continuam como estão. Na perda que passou a ser a número 1, o motivo fica: "Por que vem primeiro: você pôs em primeiro na conferência."

## A entrega: DIAGNOSTICO.md

Salve na pasta mares.ia (aba Code). Se a sessão estiver em outra pasta, avise e peça para abrir a mares.ia.

```markdown
# Diagnóstico de maturidade · [Empresa]
[data] · Imersão Mares.IA

## Em 3 linhas
- Maturidade para IA: [média] de 5 ([nível]). Mais forte: [área]. Mais frágil: [área].
- Prioridade número 1: [a perda que vem primeiro].
- Primeiro desafio: [o primeiro item da sequência].

## 1. Maturidade
| Área | Nota (1 a 5) | O que a resposta mostra |
|---|---|---|

## 2. Possíveis perdas, em ordem de prioridade
| # | Possível perda | Tipo | Por que está nesta posição | Valor por mês |
|---|---|---|---|---|
| 1 | | | a que mais pesa, segundo o dono / área mais frágil / tem número | R$ [conta] (estimativa) ou "sem dado ainda" |

## 3. Sequência de desafios
| Ordem | Desafio | Por que vem nesta posição |
|---|---|---|

## Para conferir
[itens marcados VERIFICAR e os dados que vale começar a registrar]
```

O Cérebro (skill `mares-ia-cerebro`) usa este arquivo, e o Mapa de oportunidades (skill `mares-ia-mapa`) transforma estas prioridades em frentes de trabalho.

## Guardar a rodada anterior (histórico)

A skill nunca muda com o uso; o que muda é o resultado de cada rodada, salvo na pasta mares.ia. Para não perder a rodada anterior:

1. Antes do "Está de acordo?" do fechamento, veja se já existe o DIAGNOSTICO.md na pasta mares.ia.
2. Se existir, leia o nome da empresa no título do arquivo (a linha '# Diagnóstico de maturidade · [Empresa]').
   - Se for a mesma empresa, avise em uma linha: "Já existe uma versão de [data]. Vou guardar essa no histórico e salvar a nova no lugar."
   - Se for outra empresa, pare e não mexa em nada. Não diga o nome da outra empresa. Diga: "Esta pasta já tem o diagnóstico de outra empresa. Cada empresa precisa da sua própria pasta mares.ia, para os dados não se misturarem. Abra a pasta certa, ou crie uma nova, e me avise." Só salve depois que a pessoa estiver na pasta certa.
3. **Guarde a anterior** na subpasta **historico** da mares.ia (crie se não existir), com a data dela na frente do nome: por exemplo `historico/2026-11-28_DIAGNOSTICO.md`. A data é a que estiver escrita no topo do arquivo; se não houver, use a data em que ele foi salvo. Nunca apague a versão anterior.
4. **Salve a nova com o nome de sempre**, sem data, porque é esse nome que as outras skills leem.
5. Compare com a rodada anterior no resultado: a nota geral e a de cada área antes e agora, e o que saiu ou entrou na lista de perdas.

## Fechamento: a pessoa aprova antes de guardar

Esta regra vale sobre qualquer outra desta skill.

Quando o trabalho estiver pronto, não guarde direto como versão final:

1. Antes de mostrar o resumo final, siga a seção "Guardar a rodada anterior (histórico)": veja se já existe DIAGNOSTICO.md na pasta e, se for de outra empresa, siga o que está lá antes de continuar. Assim você já sabe o nome e o lugar do arquivo. Depois mostre o resultado final em poucas linhas: o que vai ficar guardado e onde.
2. Pergunte, com estas palavras: **"Finalizamos aqui. Esta é a versão final. Está de acordo?"**, com as opções A) Estou de acordo, pode guardar · B) Quero ajustar alguma coisa. Se tiver a ferramenta de pergunta com opções, use-a.
3. Se a resposta for B, ajuste o que a pessoa pedir, uma coisa por vez, e pergunte de novo.
4. Só depois do "de acordo", salve o arquivo como versão final e diga em uma linha onde ele ficou guardado. A última frase, depois de gravar, é esta: Agora você pode ir para o Bloco 2, Cérebro (skill mares-ia-cerebro). Abra uma sessão nova na pasta mares.ia e diga: "montar o cérebro da empresa".
