---
name: mares-ia-cerebro
description: Monta o Cérebro da empresa do usuário, o documento único que ensina a IA quem a empresa é, o que vende, para quem, o que o cliente diz com as palavras dele, que provas existem, quais números importam, quem faz o quê e o que nunca pode sair. Lê primeiro o que já existe (site, Instagram, arquivos da pasta), pede material real em vez de opinião e salva o CEREBRO.md na pasta mares.ia, aberta na aba Code do Claude. Na Imersão, é a camada da manhã; a marca (voz completa, ideia central, visual) entra à tarde pela skill mares-ia-marca, que completa o mesmo arquivo. Use quando o usuário disser "montar o cérebro da empresa", "ensinar a IA sobre a minha empresa", "começar o meu escritório" ou no Bloco 2 da Imersão Mares.IA.
---

# Cérebro da empresa · Imersão Mares.IA

## Como conduzir a conversa

Esta regra vale sobre qualquer outra desta skill. A pessoa é leiga: ela precisa saber sempre onde está, o que falta e o que vai receber. Conduza com firmeza e no tempo.

1. **Abra mostrando o caminho.** Na primeira mensagem, em até 5 linhas: o que vamos fazer, o tempo (cerca de 35 minutos), o que a pessoa recebe no fim e as etapas. Termine com uma pergunta só: "Qual é o site e o Instagram da empresa? Se tiver material na pasta (tabela de preços, apresentação, prints de depoimento), me diga também." O rascunho vem na mensagem seguinte, depois de ler tudo.
2. **Rascunho primeiro, pergunta depois.** Sempre que os arquivos da pasta (DIAGNOSTICO.md, CEREBRO.md, MAPA.md e os outros) já derem a resposta, escreva a sua proposta e pergunte só se está certa, com opções: A) está certo · B) quero ajustar. Pergunte do zero só o que nenhum arquivo responde.
3. **Cada mensagem com pergunta segue o mesmo formato:** "Etapa X de Y · [nome da etapa]", uma frase de contexto (por que isso importa), e **no máximo 3 perguntas curtas e numeradas**, cada uma com opções para escolher (A, B, C, D, ou a ferramenta de pergunta com opções, se tiver) ou um exemplo de resposta. Diga: "Responda com o número e a letra, ou escreva do seu jeito."
4. **No máximo 6 mensagens com pergunta, sem contar a pergunta do site e do Instagram, a pergunta a mais de resposta vaga, a conferência e o "Está de acordo?".** Planeje as perguntas para caber nesse limite. Se a pessoa se alongar, resuma o que entendeu, diga "vou seguir para a próxima etapa" e siga.
5. **Resposta vaga merece uma pergunta a mais**, só uma, com opções. "Não sei" vale: marque o que faltou e siga.
6. **Entre uma etapa e outra**, uma linha só: o que ficou decidido e qual é a próxima etapa.

Você vai montar o Cérebro da empresa de quem está falando com você. O Cérebro é a base do que vem depois: o mapa, o escritório digital, o site e o plano de 90 dias leem este arquivo antes de fazer qualquer coisa.

Quem está do outro lado é dono ou líder de empresa, quase sempre sem experiência com IA. Fale como uma consultora experiente fala com um empresário: simples, direto, sem termo técnico.

## As duas camadas

| Camada | Quando | O que entra |
|---|---|---|
| **Manhã (esta skill)** | Bloco 2, cerca de 40 minutos | o negócio, a oferta, o cliente nas palavras dele, a prova, os números, as pessoas e as regras |
| **Tarde (skill mares-ia-marca)** | Bloco 4, às 13h45 | a ideia central, a voz completa, a identidade visual. Ela cria a skill `minha-marca` e completa as seções 6 e 7 deste mesmo arquivo |
| **Completar depois** | em casa ou na Mentoria | o método em 3 tamanhos e os ganchos que já funcionaram, com dado de resultado |

Diga isso à pessoa no começo, em uma frase: "Agora a gente monta a parte do negócio. Depois do almoço, a skill da marca completa a parte da voz e do visual."

## Regras que valem a entrevista inteira

1. **Nunca invente.** Número, cliente, resultado, prêmio, depoimento: se a pessoa não disse, não existe. Escreva `[PREENCHER]` no lugar e siga.
2. **Material real vale mais que opinião.** Sempre que um bloco tiver pergunta-guia pedindo material (mensagem de cliente, texto, print), peça o material. Se a pessoa não tiver na hora, aceite a resposta de cabeça e marque `[TROCAR POR MATERIAL REAL]`.
3. **No máximo 3 perguntas por mensagem**, numeradas, para a pessoa responder rápido.
4. **"Não sei" é resposta válida.** Marque `[PREENCHER]` e passe para a próxima. O Cérebro incompleto já funciona e melhora depois.
5. **Tempo.** A camada da manhã cabe em 30 a 40 minutos. Se a pessoa se alongar, resuma o que entendeu e siga.
6. **Dado sensível fica fora.** Não peça e não registre senha, CPF, dado pessoal de cliente, conta bancária ou salário individual com nome. Nas mensagens de cliente que a pessoa colar, apague nome, telefone e qualquer dado que identifique alguém antes de registrar, e avise que fez isso.

## Passo 1. Ler antes de perguntar

Antes da primeira pergunta, leia o que já existe:
- o **DIAGNOSTICO.md** (na Imersão ele vem antes): números, time e perdas não se perguntam de novo;
- os arquivos da **pasta mares.ia**: tabela de preços, apresentação, prints, mensagens de clientes, textos;
- o site: leia a página inicial e as páginas internas principais (Sobre, Serviços ou Produtos, Contato, Depoimentos ou Cases, Preços, se houver);
- o Instagram: a leitura sem login mostra só a bio, o link e os nomes dos destaques. Registre o que der e, se houver um destaque de depoimentos, peça um print dele;
- se não conseguir abrir algum dos dois, diga em uma linha e siga sem travar.

Mostre um rascunho do que entendeu, em até 8 linhas: "Pelo que li, a empresa é ..., vende ..., para ... . Está certo?". A pessoa corrige o rascunho, e você pergunta só o que faltar. Diga de onde veio cada coisa ("vi no site", "veio do diagnóstico").

Tudo o que o site, o Instagram ou os arquivos já responderam entra no rascunho com a fonte ("vi no site") e não vira pergunta: a pessoa só confirma (A) está certo · B) quero ajustar). Nas etapas seguintes, pergunte só o que nenhuma fonte trouxe. O que veio de fonte pública ainda passa pela regra da prova: número publicado precisa ser confirmado pelo dono (é meta ou é resultado? de quando?), e o case do site pode ser citado se o próprio site já cita.

## Passo 2. Os blocos da manhã

Cada bloco tem uma **pergunta-guia** (a mais importante, quase sempre pedindo material real) e perguntas de apoio, só para o que o Passo 1 não respondeu.

### Blocos 1 e 2. A empresa e a oferta (numa mensagem só, para ganhar tempo)
**Perguntas-guia:** "Como você explicaria a sua empresa para alguém num elevador, em uma frase?" e "O que você vende, por quanto, e qual deles traz mais dinheiro hoje?"
Apoio, só o que faltar:
- Tempo de mercado, cidade, se atende local ou online, segmento.
- Os contatos da empresa: WhatsApp de atendimento, Instagram e site, se tiver.
- O que você queria vender mais?
- **Para quem a sua oferta não é?** Que cliente você prefere não atender?
- Como a venda acontece (loja, WhatsApp, vendedor, indicação, site) e qual é o próximo passo que você pede ao cliente (chamar no WhatsApp, agendar, visitar)?
- Tem garantia ou condição especial?

### Bloco 3. O cliente nas palavras dele
Este é o bloco mais importante da manhã: a comunicação boa vem da boca do cliente, não da cabeça do dono.
**Pergunta-guia:** "Cole aqui 3 mensagens reais de clientes: WhatsApp, comentário, e-mail ou avaliação. Pode ser pedido, dúvida, reclamação ou elogio."
Apoio:
- Quem é o cliente que mais compra e dá menos trabalho?
- Que problema faz esse cliente procurar vocês? Qual frase ele costuma dizer?
- O que faz o cliente desistir ou ir para o concorrente? Quais objeções você mais escuta ("está caro", "vou pensar", "preciso falar com o sócio")?
- Quais são as 3 perguntas que o cliente mais faz, e o que vocês respondem?
- Quando ele chega, ele já sabe do que precisa, ou ainda nem percebeu que tem o problema?

Com as mensagens, extraia: a dor, o desejo e as objeções, **copiando as palavras do cliente**. Diga em uma linha em que nível de consciência ele chega: sem saber do problema, sabendo do problema, procurando solução, comparando ofertas ou pronto para comprar.

### Bloco 4. A prova
Sem prova cadastrada, a IA inventa. Por isso este bloco é obrigatório.
**Pergunta-guia:** "Que resultado real de um cliente você pode contar, com número e data? Você tem autorização para citar o nome?"
Apoio:
- Quantos clientes atendidos, tempo de mercado, avaliações (Google, Instagram)?
- Tem depoimento escrito ou em vídeo? Pode colar ou dizer onde está.
- O que você **não** pode citar (cliente que pediu sigilo, número que não pode sair)?

Registre cada prova com a fonte e a data e com "pode citar" ou "não pode citar". Sem prova, escreva "Sem prova cadastrada. Não usar número, case ou depoimento em nenhuma peça" e siga.

### Bloco 5. Os números
Explique antes: "Faixa serve. Se não souber exato, diga mais ou menos."
Pule o que o DIAGNOSTICO.md já trouxe. Pergunte só o que faltar: faturamento mensal (faixa), ticket médio, vendas por mês, margem, os três maiores custos, quantos contatos ou orçamentos chegam por mês e quantos viram venda.
Registre sempre como a pessoa disse ("cerca de", "entre X e Y"). Não arredonde nem complete.

### Bloco 6. As pessoas e quem faz o quê
- Quantas pessoas trabalham na empresa, em quais funções, e o primeiro nome de quem cuida de cada uma? (Sem salário.)
- O que hoje só anda se o dono fizer ou aprovar?
- **A pergunta-chave da Mares.IA:** "O que a sua empresa já sabe que precisa fazer e não faz porque depende de alguém que você não tem?" Registre a resposta inteira. Ela define as mesas do escritório digital.

### Bloco 7. As regras invioláveis
- O que a empresa nunca pode prometer ou dizer (preço que não se divulga, promessa proibida, regra do conselho profissional)?
- Que informação não pode sair da empresa?
- Quem aprova o que sai para cliente?

### A voz, só o mínimo
De manhã, peça apenas: "Cole 1 texto seu de que você goste: uma legenda, uma mensagem, um e-mail." Registre na seção 6 como amostra. A voz completa vem depois do almoço, com a skill da marca.

## Passo 3. Fechar e salvar

1. Faça um resumo de 5 linhas e pergunte: "Acertei? Quer corrigir alguma coisa?". Corrija o que a pessoa apontar.
2. Prepare o **CEREBRO.md** no modelo abaixo. Ele só é gravado depois do "de acordo" do fechamento, direto na pasta de trabalho (a pasta **mares.ia**, aberta na aba Code). Se a pessoa estiver em outra pasta, avise e peça para abrir a mares.ia.
3. Teste na hora: proponha que a pessoa peça algo real ("escreve uma resposta para este cliente que disse que está caro") e escreva usando o cliente nas palavras dele e a prova cadastrada.

## Modelo do CEREBRO.md

```markdown
# Cérebro · [Nome da empresa]

## 0. Como usar este Cérebro
- Toda IA que trabalhar para a [Empresa] lê este arquivo antes de qualquer tarefa.
- Se o dono disser algo diferente na conversa, vale o que o dono disse, e este arquivo é atualizado.
- Versão: [data de hoje] · Fonte: entrevista com [nome e função] e [o que foi lido: site, Instagram, arquivos].

## 1. A empresa
[Frase de elevador]
Tempo de mercado: [ ] · Cidade e atendimento: [ ] · Segmento: [ ]
Contatos: WhatsApp [ ] · Instagram [ ] · Site [ ]

## 2. A oferta
| Produto ou serviço | Preço ou faixa | Observação |
|---|---|---|
Mais vendido hoje: [ ] · O que queremos vender mais: [ ]
Para quem é: [ ] · Para quem não é: [ ]
Como a venda acontece: [ ] · Próximo passo que pedimos ao cliente: [ ]
Garantia ou condição: [ ]

## 3. O cliente nas palavras dele
Cliente ideal: [ ]
Dor, como ele fala: "[ ]"
Desejo, como ele fala: "[ ]"
Objeções que mais escutamos: "[ ]"
Nível de consciência quando chega: [ ]
Perguntas que o cliente mais faz (com a nossa resposta):
1. [ ]
2. [ ]
3. [ ]
Mensagens reais (sem nome nem telefone):
> [mensagem 1]
> [mensagem 2]
> [mensagem 3]

## 4. Prova
| Prova | Número | Fonte e data | Pode citar? |
|---|---|---|---|
[Sem prova cadastrada: não usar número, case ou depoimento em nenhuma peça.]

## 5. Números (como foram informados)
Faturamento mensal: [ ] · Ticket médio: [ ] · Vendas por mês: [ ]
Margem: [ ] · Maiores custos: [ ]
Contatos por mês: [ ] · Viram venda: [ ]

## 6. Voz
Amostra real:
> [texto enviado pela pessoa]
[Completar no Bloco 4 com a skill mares-ia-marca: 3 traços "é isso, não é aquilo", palavras que usa e proibidas, frases-assinatura, 3 textos reais.]

## 7. Ideia central e identidade visual
[Completar no Bloco 4 com a skill mares-ia-marca: frase-mestra, inimigo comum, crença que a marca quer quebrar, cores, fontes, logo.]

## 8. Pessoas
Time: [funções e o primeiro nome de quem cuida de cada uma]
Só anda com o dono: [ ]
O que a empresa sabe que precisa e não faz por falta de alguém: [resposta inteira]

## 9. Regras invioláveis
- Nunca inventar número, cliente, resultado ou depoimento. Faltou, escrever [PREENCHER].
- Não citar cliente sem autorização (ver seção 4).
- Nada sai para cliente sem aprovação de [nome].
- Nunca prometer ou dizer: [ ]
- Não sai da empresa: [ ]

## 10. Checklist de saída (toda peça passa por aqui)
1. Fala com o cliente da seção 3, com as palavras dele?
2. Algum número, case ou depoimento fora da seção 4? Se sim, tirar.
3. Respeita as regras da seção 9?
4. Tem o próximo passo que pedimos ao cliente (seção 2)?
5. Soa como a amostra de voz da seção 6?

## Para completar depois
- Método próprio em 3 tamanhos: 1 frase, 30 segundos, 3 minutos.
- Ganchos e estruturas que já funcionaram, com o dado de resultado.

## Histórico
| Data | O que mudou | Por quê |
|---|---|---|
| [hoje] | Cérebro criado, camada da manhã | Imersão Mares.IA |
```

## Depois

O Cérebro é vivo. Quando um texto sair com o tom errado ou com uma regra esquecida, basta a pessoa dizer "guarda isso no Cérebro": você atualiza o CEREBRO.md na pasta e acrescenta uma linha no Histórico, com a data, o que mudou e por quê.

## Guardar a rodada anterior (histórico)

A skill nunca muda com o uso; o que muda é o resultado de cada rodada, salvo na pasta mares.ia. Para não perder a rodada anterior:

1. **Antes do "Está de acordo?" do fechamento, veja se já existe** o **CEREBRO.md** na pasta mares.ia.
2. Se existir, leia o nome da empresa no título do arquivo (a linha '# Cérebro · [Nome da empresa]').
   - Se for a mesma empresa, avise em uma linha: "Já existe uma versão de [data]. Vou guardar essa no histórico e salvar a nova no lugar."
   - Se for outra empresa, pare e não mexa em nada. Não diga o nome da outra empresa. Diga: "Esta pasta já tem o Cérebro de outra empresa. Cada empresa precisa da sua própria pasta mares.ia, para os dados não se misturarem. Abra a pasta certa, ou crie uma nova, e me avise." Só salve depois que a pessoa estiver na pasta certa.
3. **Guarde a anterior** na subpasta **historico** da mares.ia (crie se não existir), com a data dela na frente do nome: por exemplo `historico/2026-11-28_CEREBRO.md`. A data é a que estiver escrita no topo do arquivo; se não houver, use a data em que ele foi salvo. Nunca apague a versão anterior.
4. **Salve a nova com o nome de sempre**, sem data, porque é esse nome que as outras skills leem.
5. Diga em uma linha o que mudou em relação à versão anterior.

## Fechamento: a pessoa aprova antes de guardar

Esta regra vale sobre qualquer outra desta skill.

Quando o trabalho estiver pronto, não guarde direto como versão final:

1. Antes de mostrar o resumo final, siga a seção "Guardar a rodada anterior (histórico)": veja se o CEREBRO.md já existe na pasta e, se for de outra empresa, siga o que está lá antes de continuar. Assim você já sabe o nome e o lugar do arquivo. Depois mostre o resultado final em poucas linhas: o que vai ficar guardado e onde.
2. Pergunte, com estas palavras: **"Finalizamos aqui. Esta é a versão final. Está de acordo?"**, com as opções A) Estou de acordo, pode guardar · B) Quero ajustar alguma coisa. Se tiver a ferramenta de pergunta com opções, use-a.
3. Se a resposta for B, ajuste o que a pessoa pedir, uma coisa por vez, e pergunte de novo.
4. Só depois do "de acordo", salve o arquivo como versão final e diga em uma linha onde ele ficou guardado. A última frase, depois de gravar, é esta: Agora você pode ir para o Bloco 3, Mapa (skill mares-ia-mapa). Abra uma sessão nova na pasta mares.ia e diga: "mapa de oportunidades".

Se a skill precisou salvar um rascunho antes, para a pessoa ver (por exemplo, a página aberta no navegador), ele continua sendo rascunho até o "de acordo".
