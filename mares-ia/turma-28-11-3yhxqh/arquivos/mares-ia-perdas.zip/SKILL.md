---
name: mares-ia-perdas
description: Faz o diagnóstico de maturidade da empresa para usar IA de forma estratégica e encontra onde a empresa está perdendo tempo, margem e capacidade, com número estimado e a conta mostrada. Lê o Cérebro da empresa, o resultado do RaioX MARES e os números que o usuário trouxer, e devolve o arquivo DIAGNOSTICO.md. Use quando o usuário pedir "onde a minha empresa está perdendo", "diagnóstico de maturidade", "fazer o diagnóstico" ou no Bloco 1 da Imersão Mares.IA.
---

# Onde a empresa perde · Imersão Mares.IA

Antes de falar de ferramenta, a gente encontra o gargalo. Este é o primeiro exercício do dia, e ele precisa entregar uma descoberta real em até 45 minutos.

## Regras

1. **Número com a conta na frente.** Toda perda vem com a conta que gerou o valor, para o dono conferir: "6 horas por semana × R$ 40 a hora × 4 semanas = R$ 960 por mês".
2. **Estimativa se chama estimativa.** Escreva "estimativa" ao lado de todo número que não veio pronto da empresa. Nunca escreva "você está perdendo R$ X" como fato.
3. **Nunca invente.** Se faltar um dado para a conta, pergunte uma vez. Sem resposta, marque `[VERIFICAR]` e use um intervalo explicado.
4. **Linguagem de dono.** Margem, caixa, tempo, cliente, fila. Nada de jargão de tecnologia.
5. **No máximo 3 perguntas por mensagem.**

## O que ler primeiro

- O **CEREBRO.md**, se já existir. Na Imersão ele ainda não existe neste bloco: comece com 3 perguntas numa mensagem só (o que a empresa vende e o ticket médio, quantas pessoas e em quais funções, faturamento mensal em faixa) e siga.
- O resultado do **RaioX MARES**, se a pessoa trouxer (nível, nota das 7 dimensões, dimensão mais frágil).
- Planilhas, relatórios ou prints de números que estiverem na pasta **mares.ia** (a pasta de trabalho).

Diga o que você leu e o que já percebeu antes de perguntar qualquer coisa.

## Passo 1. Maturidade em 7 dimensões

Use as mesmas 7 dimensões do RaioX MARES:

| Dimensão | O que olha |
|---|---|
| Estrutura | papéis, processos escritos, quem é dono de quê |
| Decisão | se decide com número ou com sensação, se existe meta e acompanhamento |
| Pessoas | liderança, autonomia, quanto depende do dono |
| Inovação | velocidade para testar e mudar |
| Tecnologia | onde os dados moram, se estão organizados, que ferramentas usa |
| Cliente | relacionamento, pós-venda, recompra |
| Mkt e Vendas | de onde vem cliente, previsibilidade, conversão |

Se a pessoa já tem o RaioX, use as notas dele. Se não tem, mande as 7 dimensões numa mensagem só, cada uma com uma frase curta do que é nota 1 e do que é nota 5, e peça uma nota de 1 a 5 para cada (exceção à regra das 3 perguntas, para caber no tempo). Mostre a tabela com a nota de cada dimensão e diga qual é a mais frágil e qual é a mais forte. Se a diferença entre elas for de 2 pontos ou mais, avise: a dimensão forte pode estar escondendo o custo da fraca.

Depois responda à pergunta que interessa para IA: **o que precisa existir antes de a IA dar resultado aqui?** Olhe quatro coisas e diga sim, em parte ou não para cada uma:

- O dado existe e está registrado em algum lugar?
- O processo está escrito, ou só existe na cabeça de alguém?
- Existe um responsável por esse processo?
- Existe regra de uso de IA na empresa?

Explique em uma frase: IA em cima de processo ruim só faz o erro acontecer mais rápido.

## Passo 2. As perdas

Procure perdas em quatro lugares. Pergunte com exemplos para destravar a memória do dono.

| Tipo | Pergunta para fazer | Como calcular |
|---|---|---|
| Tempo | "Que tarefa toma horas toda semana e é sempre igual?" | horas por semana × custo da hora de quem faz × 4 |
| Margem | "Onde sai dinheiro sem precisar? Retrabalho, erro, desconto, devolução?" | ocorrências por mês × custo de cada uma |
| Capacidade | "O que fica na fila? Orçamento sem resposta, cliente sem retorno, lead que esfria?" | oportunidades perdidas por mês × taxa de conversão × ticket |
| Dependência do dono | "O que para quando você não está?" | horas do dono por semana × valor da hora do dono × 4 |

Custo da hora: salário da função dividido por 160. Sem dado de encargos, use só o salário e avise que o custo real é maior. Pergunte o salário da função, nunca o salário de uma pessoa com nome. Hora do dono: o quanto ele tira por mês dividido por 160; se não quiser dizer, registre só as horas, sem valor em reais. Conversão desconhecida: use o intervalo de 20% a 40% e escreva "suposição".

Pergunte os quatro tipos numa mensagem só, com um exemplo em cada, e deixe a pessoa responder os que lembrar.

Para cada perda, registre: o que é, onde acontece, a conta, o valor estimado por mês e de onde veio cada número (informado pela pessoa ou suposição sua).

## Passo 3. As 5 maiores

Ordene as perdas pelo valor estimado por mês e mostre até 5. Não complete a lista só para chegar a 5. Perda sem número vai numa linha à parte, sem valor. Para cada uma, uma frase de "por que isso acontece", ligando com a dimensão mais frágil quando fizer sentido.

Feche com uma frase só, sem exagero, do tipo: "Somando as cinco, a estimativa é de R$ X a R$ Y por mês. O maior pedaço está em Z."

Pergunte: "Isso bate com o que você sente no dia a dia?". Ajuste o que a pessoa corrigir.

## O arquivo DIAGNOSTICO.md

Salve o arquivo **DIAGNOSTICO.md** direto na pasta de trabalho (a pasta **mares.ia**, aberta na aba Code). Se a pessoa estiver em outra pasta, avise e peça para abrir a mares.ia. Depois diga em uma linha: "Salvei o DIAGNOSTICO.md na sua pasta mares.ia."

```markdown
# Diagnóstico · [Empresa]
[data] · feito na Imersão Mares.IA

## Maturidade
| Dimensão | Nota (1 a 5) | Leitura |
|---|---|---|
Mais frágil: [ ] · Mais forte: [ ] · Diferença: [ ]

## O que precisa existir antes da IA
| Item | Situação | O que fazer |
|---|---|---|
| Dado registrado | sim / em parte / não | |
| Processo escrito | | |
| Responsável | | |
| Regra de uso de IA | | |

## As maiores perdas (estimativa, até 5)
| # | Perda | Tipo | Conta | R$ por mês | Origem dos números |
|---|---|---|---|---|---|

Total estimado: R$ [ ] a R$ [ ] por mês.

## Para conferir
[itens marcados VERIFICAR]
```

O próximo passo do dia é o Cérebro (skill `mares-ia-cerebro`), e depois o Mapa de oportunidades (skill `mares-ia-mapa`), que transforma estas perdas em prioridades.
