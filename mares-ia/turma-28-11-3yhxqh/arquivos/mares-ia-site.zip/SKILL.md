---
name: mares-ia-site
description: Cria a página da empresa (site de uma página) a partir do Cérebro, num único arquivo index.html pronto para guardar no GitHub e publicar na Vercel, com botão de WhatsApp, visual nas cores da marca e funcionando no celular, e guia o usuário leigo até o site estar no ar. Use quando o usuário pedir "fazer o meu site", "criar uma página", "landing page", "colocar o site no ar", "pedido para a mesa Site" ou no Bloco 6 da Imersão Mares.IA.
---

# Site no ar · Imersão Mares.IA

## Como conduzir a conversa

Esta regra vale sobre qualquer outra desta skill. A pessoa é leiga: ela precisa saber sempre onde está, o que falta e o que vai receber. Conduza com firmeza e no tempo.

1. **Abra mostrando o caminho.** Na primeira mensagem, em até 5 linhas: o que vamos fazer, o tempo (cerca de 15 minutos até a página pronta), o que a pessoa recebe no fim (a página da empresa no arquivo **index.html**, na pasta mares.ia, e, se houver as contas, o link .vercel.app abrindo no celular) e as etapas: 1) confirmar o que vai na página · 2) ver a página e ajustar uma vez. Se já leu arquivos da pasta, diga o que leu e que vai pular o que já sabe.
2. **Rascunho primeiro, pergunta depois.** Sempre que os arquivos da pasta (DIAGNOSTICO.md, CEREBRO.md, MAPA.md e os outros) já derem a resposta, escreva a sua proposta e pergunte só se está certa, com opções: A) está certo · B) quero ajustar. Pergunte do zero só o que nenhum arquivo responde.
3. **Cada mensagem com pergunta segue o mesmo formato:** "Etapa X de Y · [nome da etapa]", uma frase de contexto (por que isso importa), e **no máximo 3 perguntas curtas e numeradas**, cada uma com opções para escolher (A, B, C, D, ou a ferramenta de pergunta com opções, se tiver) ou um exemplo de resposta. Diga: "Responda com o número e a letra, ou escreva do seu jeito."
4. **No máximo 2 mensagens com pergunta nesta skill.** Planeje as perguntas para caber nesse limite. Se a pessoa se alongar, resuma o que entendeu, diga "vou seguir para a próxima etapa" e siga.
5. **Resposta vaga merece uma pergunta a mais**, só uma, com opções. "Não sei" vale: marque o que faltou e siga.
6. **Entre uma etapa e outra**, uma linha só: o que ficou decidido e qual é a próxima etapa.

Você vai criar a página da empresa e levar a pessoa até o link funcionando no celular.

Na Imersão, este site é uma **página de demonstração**: o objetivo é a pessoa saber como se faz. Muitas empresas já têm site e Instagram; nada do resto do dia depende desta página. Se a pessoa não tiver a conta do GitHub ou da Vercel, faça a página e pare antes de publicar: ela publica depois, com o Manual. A pessoa é leiga: cada passo de publicação precisa ser um clique descrito em palavras.

Se o pedido veio pela mesa Site do escritório, siga o caminho do pedido do ESCRITORIO.md: a Direção revisa com o checklist antes de mostrar, e o quadro é atualizado no fim.

## Regras da página

1. **Tudo vem do Cérebro e da marca.** Promessa, oferta, cliente, provas, voz, cores e links saem do CEREBRO.md. Se existir a skill `minha-marca` (criada pela skill mares-ia-marca, na pasta `.claude/skills` da mares.ia), use a voz, a ideia central, as cores e as fontes dela. Se existir o arquivo benchmark-*.md da pasta (ou BENCHMARK-*.md), use os espaços vazios do mercado e o que o cliente reclama dos concorrentes para afiar a promessa e os diferenciais, sem citar concorrente pelo nome. Sem Cérebro, faça só 5 perguntas rápidas (nome, o que vende, para quem, WhatsApp, cores) e siga.
2. **Nunca invente prova.** Sem número, depoimento ou cliente real no Cérebro, a seção de provas não existe. Não escreva "centenas de clientes satisfeitos" nem nada parecido.
3. **Um arquivo só.** Um `index.html` com o CSS dentro. Fontes do Google Fonts podem ser usadas. Sem JavaScript obrigatório, sem bibliotecas externas.
4. **Sem formulário e sem coleta de dados.** O contato é um botão de WhatsApp. Isso evita guardar dado de cliente sem regra.
5. **Sem rastreamento.** Não inclua pixel, Analytics nem script de terceiros.
6. **Celular primeiro.** A maioria vai abrir no celular. Texto legível, botões grandes, nada estourando a tela.
7. **Respeite a seção 9 do Cérebro** (regras invioláveis) e cite só a prova marcada "pode citar" na seção 4.

## Estrutura da página

Na ordem, encurtando o que não tiver conteúdo:

1. **Topo:** nome da empresa (ou espaço para o logo) e botão de WhatsApp.
2. **Promessa:** título com o resultado que o cliente quer, nas palavras dele; uma frase de apoio; botão principal de WhatsApp.
3. **Para quem é:** 3 situações em que o cliente se reconhece, tiradas da seção 3 do Cérebro (o cliente nas palavras dele).
4. **O que fazemos:** produtos ou serviços principais, com preço só se o Cérebro permitir divulgar.
5. **Como funciona:** 3 passos, do primeiro contato ao resultado, a partir da seção 2 do Cérebro (como a venda acontece e o próximo passo que a empresa pede ao cliente). Se não estiver claro, pergunte uma vez.
6. **Provas:** só se existirem no Cérebro.
7. **Quem somos:** 3 a 4 linhas com a diferença concreta.
8. **Perguntas frequentes:** as da seção 3 do Cérebro ("Perguntas que o cliente mais faz"), com a resposta dada pela empresa. Sem elas, a seção não existe.
9. **Chamada final:** frase curta e botão de WhatsApp.
10. **Rodapé:** nome, cidade, redes sociais, ano.

### O botão de WhatsApp
Use o formato `https://wa.me/55DDDNUMERO?text=` com uma mensagem pronta codificada para URL, por exemplo `Oi! Vi o site e quero saber mais.` Confirme o número com a pessoa antes de gerar. Abra o link em nova aba.

### Visual
- Cores do Cérebro: uma cor principal para botões, uma escura para textos, fundo claro. Garanta contraste bom para leitura.
- Uma família de fonte para títulos e outra para texto, ou a mesma em pesos diferentes.
- Bastante espaço em branco, títulos grandes, no máximo 3 frases por parágrafo.
- Se a pessoa mandou um print de um site que admira, use como referência de estilo, nunca como cópia de texto.
- Inclua `<meta name="viewport" content="width=device-width, initial-scale=1">`, `<title>` com o nome da empresa e uma `<meta name="description">` de uma frase.

### Logo e fotos
Por padrão, a página não usa imagem (o nome vira o logo em texto). Se a pessoa quiser logo ou fotos, explique que então ela vai enviar ao GitHub o `index.html` e as imagens juntos, no mesmo envio, com nomes simples sem espaço nem acento (`logo.png`, `foto1.jpg`). Use esses nomes no código.

## Mostrar antes de publicar

Salve o `index.html` na pasta mares.ia **como rascunho** antes de mostrar (ele só vira versão final depois do "de acordo" do fechamento), e diga: "Abra a pasta mares.ia e dê dois cliques no index.html: ele abre no navegador." Mostre também a prévia, se você puder exibir páginas. Peça no máximo duas rodadas de ajuste ("quer mudar texto, cor ou ordem?"). Depois do 'de acordo', salve o arquivo final index.html na pasta mares.ia.

## Publicar: GitHub guarda, Vercel coloca no ar

A pessoa criou as contas do GitHub e da Vercel na aula de quinta (a Vercel entrando com o GitHub). Escreva estes passos exatamente assim, adaptando só o que estiver entre colchetes:

> 1. Abra a pasta **mares.ia** (Documentos) no Explorador de Arquivos: o **index.html** está lá.
> 2. Abra **github.com/new** no navegador, já entrando na sua conta do GitHub.
> 3. Em **Repository name**, escreva **site-[nome-da-empresa]**, sem espaço e sem acento. Deixe marcado **Public** e clique em **Create repository**.
> 4. Na página que abrir, clique no link **uploading an existing file**.
> 5. Arraste o **index.html** (e as imagens, se tiver) para o quadro e clique no botão verde **Commit changes**.
> 6. Abra **vercel.com/new**. Na lista de repositórios, ache o **site-[nome-da-empresa]** e clique em **Import**. Se ele não aparecer, clique em **Adjust GitHub App Permissions** e libere o repositório.
> 7. Não mude nada nas configurações. Clique em **Deploy** e espere cerca de 1 minuto, até aparecer a tela de parabéns.
> 8. Clique na imagem do site ou em **Continue to Dashboard** e depois no endereço terminado em **.vercel.app**.
> 9. Abra o mesmo endereço no celular, pelo 4G.

Se der erro, peça um print da tela e resolva a partir do que aparecer.

## Depois do site no ar

- **Mudar alguma coisa:** peça a alteração aqui (o Claude atualiza o index.html na pasta mares.ia), abra o repositório no GitHub, clique em **Add file**, **Upload files**, arraste o arquivo novo e clique em **Commit changes**. A Vercel publica a versão nova sozinha em cerca de 1 minuto.
- **Este é um site de teste.** O plano grátis da Vercel (Hobby) é para uso pessoal, sem fim comercial, e permite que a Vercel use o conteúdo para treinar a IA dela. Para o site definitivo da empresa, oriente a pessoa a decidir onde publicar conversando com você (o Claude) e com a equipe de TI da empresa, comparando segurança, custo e se o plano permite uso comercial. Não escolha por ela.
- **Domínio próprio** (www.suaempresa.com.br): é um passo à parte, com custo do registro do domínio. Fica para depois do dia.
- Lembre: a página fala pela empresa. Antes de divulgar, o dono lê inteira e aprova.

## Guardar a rodada anterior (histórico)

A skill nunca muda com o uso; o que muda é o resultado de cada rodada, salvo na pasta mares.ia. Para não perder a rodada anterior:

1. **Antes do "Está de acordo?" do fechamento, veja se já existe** o **index.html** (e as imagens do site, se houver) na pasta mares.ia.
2. Se existir, veja de qual empresa é: o nome está no título do arquivo, na primeira linha (no site, no `<title>` da página; na minha-marca, no nome da empresa dentro dela).
   - Se for a mesma empresa, avise em uma linha: "Já existe uma versão de [data]. Vou guardar essa no histórico e salvar a nova no lugar."
   - Se for outra empresa, pare e não mexa em nada. Não diga o nome da outra empresa. Diga: "Esta pasta já tem o site de outra empresa. Cada empresa precisa da sua própria pasta mares.ia, para os dados não se misturarem. Abra a pasta certa, ou crie uma nova, e me avise." Só salve depois que a pessoa estiver na pasta certa.
3. **Guarde a anterior** na subpasta **historico** da mares.ia (crie se não existir), com a data dela na frente do nome: por exemplo `historico/2026-11-28_index.html`. A data é a que estiver escrita no topo do arquivo; se não houver, use a data em que ele foi salvo. Nunca apague a versão anterior.
4. **Salve a nova com o nome de sempre**, sem data, porque é esse nome que as outras skills leem.
5. Lembre que, para a mudança ir ao ar, o arquivo novo precisa ser enviado de novo ao GitHub.

## Fechamento: a pessoa aprova antes de guardar

Esta regra vale sobre qualquer outra desta skill.

Quando o trabalho estiver pronto, não guarde direto como versão final:

1. Antes de mostrar o resumo final, siga a seção "Guardar a rodada anterior (histórico)": veja se o arquivo já existe na pasta e, se for de outra empresa, siga o que está lá antes de continuar. Assim você já sabe o nome e o lugar do arquivo. Depois mostre o resultado final em poucas linhas: o que vai ficar guardado e onde.
2. Pergunte, com estas palavras: **"Finalizamos aqui. Esta é a versão final. Está de acordo?"**, com as opções A) Estou de acordo, pode guardar · B) Quero ajustar alguma coisa. Se tiver a ferramenta de pergunta com opções, use-a.
3. Se a resposta for B, ajuste o que a pessoa pedir, uma coisa por vez, e pergunte de novo.
4. Só depois do "de acordo", salve o arquivo como versão final e diga em uma linha onde ele ficou guardado. A última frase, depois de gravar, é esta: Agora você pode ir para o Bloco 7, Plano de 90 dias (skill mares-ia-plano-90). Abra uma sessão nova na pasta mares.ia e diga: "plano de 90 dias".

Se a skill precisou salvar um rascunho antes, para a pessoa ver (por exemplo, a página aberta no navegador), ele continua sendo rascunho até o "de acordo".
