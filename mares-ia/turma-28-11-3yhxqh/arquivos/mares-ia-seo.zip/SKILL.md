---
name: mares-ia-seo
description: Faz a análise de SEO e GEO de um site (o da própria empresa ou o de um concorrente): se o Google consegue ler e entender as páginas, se elas respondem ao que o cliente procura, se a empresa aparece na busca local e se os buscadores de IA (ChatGPT, Gemini, Perplexity, Copilot, respostas de IA do Google) têm o que citar. Entrega uma nota, os 5 consertos que mais trazem resultado e a lista de termos que o cliente digita. Funciona sem ferramenta paga. Salva SEO.md na pasta mares.ia. Use quando o usuário pedir "análise de SEO", "auditoria do site", "por que meu site não aparece no Google", "como aparecer no ChatGPT", "palavras-chave", "comparar meu site com o do concorrente" ou antes de usar a skill mares-ia-site-completo.
---

# Análise de SEO e GEO · Imersão Mares.IA

## Como conduzir a conversa

Esta regra vale sobre qualquer outra desta skill. A pessoa é leiga: ela precisa saber sempre onde está, o que falta e o que vai receber. Conduza com firmeza e no tempo.

1. **Abra mostrando o caminho.** Na primeira mensagem, em até 5 linhas: o que vamos fazer, o tempo (cerca de 30 minutos), o que a pessoa recebe no fim (o arquivo **SEO.md** na pasta mares.ia: a nota do site em 4 partes, os 5 consertos que mais trazem cliente e os termos que o cliente procura) e as etapas: 1) o site e os termos do cliente · 2) a leitura do site · 3) a busca local e as IAs · 4) os 5 consertos. Se já leu arquivos da pasta, diga o que leu e que vai pular o que já sabe.
2. **Rascunho primeiro, pergunta depois.** Sempre que os arquivos da pasta (DIAGNOSTICO.md, CEREBRO.md, MAPA.md e os outros) já derem a resposta, escreva a sua proposta e pergunte só se está certa, com opções: A) está certo · B) quero ajustar. Pergunte do zero só o que nenhum arquivo responde.
3. **Cada mensagem com pergunta segue o mesmo formato:** "Etapa X de Y · [nome da etapa]", uma frase de contexto (por que isso importa), e **no máximo 3 perguntas curtas e numeradas**, cada uma com opções para escolher (A, B, C, D, ou a ferramenta de pergunta com opções, se tiver) ou um exemplo de resposta. Diga: "Responda com o número e a letra, ou escreva do seu jeito."
4. **No máximo 6 mensagens com pergunta nesta skill.** Planeje as perguntas para caber nesse limite. Se a pessoa se alongar, resuma o que entendeu, diga "vou seguir para a próxima etapa" e siga.
5. **Resposta vaga merece uma pergunta a mais**, só uma, com opções. "Não sei" vale: marque o que faltou e siga.
6. **Entre uma etapa e outra**, uma linha só: o que ficou decidido e qual é a próxima etapa.

Você vai analisar um site e dizer, em linguagem de dono de empresa, o que impede o cliente de achar a empresa e o que consertar primeiro. A pessoa não é técnica: troque cada termo técnico por uma frase do que ele significa ("a página não tem a descrição que aparece embaixo do título no Google").

**SEO** é aparecer quando o cliente procura no Google. **GEO** é ser citado quando o cliente pergunta para uma IA. Os dois dependem da mesma coisa: páginas que respondem com clareza ao que o cliente quer saber.

## Regras

1. **Só o que você conferiu.** Cada problema vem com a página e o trecho que mostra o problema. Se não conseguiu abrir uma página, diga isso, não deduza.
2. **Nunca invente número** de visitas, posição no Google ou volume de busca. Sem ferramenta paga, você não tem esses números: diga "estimativa" ou peça o print do Search Console.
3. **Prioridade é impacto no cliente, não quantidade de erro.** Cinco consertos bem escolhidos valem mais que uma lista de cinquenta.
4. **Não mexe no site.** Esta skill analisa e recomenda. Quem conserta é a pessoa, ou a skill `mares-ia-site-completo`, depois da aprovação dela.

## O que ler primeiro

- **CEREBRO.md** (se existir): o que a empresa vende, para quem, a cidade, as perguntas que o cliente mais faz. É daí que saem os termos de busca.
- **BENCHMARK.md** (se existir): os concorrentes, para comparar.
- Pergunte o endereço do site. Se a pessoa não tiver site, pule para o Passo 4 (termos) e o Passo 5 (busca local) e recomende a `mares-ia-site-completo`.

## Passo 1. O que o cliente procura (os termos)

Monte, a partir do Cérebro e de uma conversa curta, de 10 a 15 termos que o cliente digitaria, **nas palavras dele, não nas da empresa**:

- **De problema:** "cansaço constante o que pode ser", "empresa cresceu e virou bagunça".
- **De solução:** "clínica de medicina integrativa", "consultoria para empresa familiar".
- **Local:** "[serviço] em [cidade]", "[serviço] perto de mim", "[serviço] [bairro]".
- **De comparação e preço:** "quanto custa [serviço]", "[serviço] vale a pena".

Para conferir se são termos reais, use o que estiver disponível: as sugestões que aparecem ao digitar no Google, a seção "As pessoas também perguntam", as perguntas que chegam no WhatsApp da empresa. Diga a fonte de cada termo. Sem ferramenta paga, não dê volume de busca.

## Passo 2. A leitura técnica (página por página)

Abra a home e as principais páginas (até 10). Para cada uma, confira:

| Item | O que olhar | Por que importa |
|---|---|---|
| Título | existe, até 60 caracteres, diz o serviço e a cidade se for local | é a linha azul do Google |
| Descrição | existe, até 155 caracteres, convida a clicar | é o texto cinza embaixo do título |
| H1 | um só, com o assunto da página | diz ao Google do que a página trata |
| Canonical | aponta para o endereço certo, com https | evita o Google ver a mesma página duas vezes |
| Celular | tem viewport, texto legível, botões grandes | o Google lê a versão de celular primeiro |
| Imagens | têm descrição (alt) e são leves | página pesada demora e perde visita |
| Links internos | as páginas se ligam entre si, nenhum quebrado | é como o Google acha o resto do site |
| Dados estruturados | tem JSON-LD (Organization, LocalBusiness, FAQPage) | ajuda o Google e a IA a entender quem é a empresa |
| Imagem de compartilhamento | tem og:image própria | é a prévia no WhatsApp |
| Indexação | a página não está com `noindex` sem querer | se estiver, ela não aparece no Google |

Na raiz do site, confira `robots.txt` (não pode bloquear o site inteiro), `sitemap.xml` (existe e lista as páginas) e `llms.txt` (opcional, ajuda as IAs).

Para medir a velocidade, sugira a pessoa abrir **pagespeed.web.dev** com o endereço do site e mandar o print. Não invente nota de velocidade.

## Passo 3. O conteúdo (o que faz o cliente e a IA escolherem a página)

- A página responde, nas primeiras linhas, o que a empresa faz, para quem e onde? (a **resposta direta**, o trecho que a IA copia)
- Os termos do Passo 1 aparecem nas páginas, do jeito que o cliente escreve?
- Existem perguntas frequentes visíveis, com respostas curtas?
- Existem provas que a IA possa citar: número com fonte e data, caso real, autor identificado com formação?
- As páginas têm conteúdo suficiente ou são só um título e um botão? (página com menos de 300 palavras raramente aparece)
- Existe blog ou artigo respondendo às perguntas de problema? É o que traz quem ainda não conhece a empresa.

## Passo 4. GEO: a empresa aparece nas IAs?

Se você tiver busca na internet, pergunte você mesmo, em 3 a 5 perguntas que o cliente faria ("qual a melhor [serviço] em [cidade]?"), e anote quem aparece e com qual fonte. Se não tiver, peça à pessoa para fazer as mesmas perguntas no ChatGPT, no Gemini e no Copilot e mandar os prints.

Depois, explique o que faz a IA citar uma empresa:
- páginas com resposta direta e perguntas frequentes;
- o nome, o endereço e o telefone iguais em todo lugar (site, Google, Instagram, diretórios);
- ser mencionada em outros sites (imprensa local, associações, parceiros, diretórios do setor);
- estar no índice do **Bing** (o Copilot e parte das outras IAs usam o Bing): cadastrar o site no Bing Webmaster Tools.

## Passo 5. Busca local (para quem atende numa cidade)

Para clínica, loja, restaurante, escritório: o **Perfil da Empresa no Google** costuma trazer mais cliente que o próprio site. Confira, buscando o nome da empresa:
- o perfil existe, está verificado, com categoria certa, horário, telefone, site e fotos reais;
- tem avaliações recentes e a empresa responde a elas;
- o nome, endereço e telefone batem com o site.

## Passo 6. Comparar com um concorrente (opcional)

Se a pessoa pedir, rode os Passos 2, 3 e 5 no site de 1 ou 2 concorrentes e mostre lado a lado só o que muda a decisão: o que eles têm que a empresa não tem, e o espaço que ninguém está ocupando. Nunca copie texto de concorrente.

## O que entregar

Salve **SEO.md** na pasta mares.ia, nesta ordem:

1. **Nota de 0 a 10** em quatro partes (técnico, conteúdo, local, IA), com uma frase explicando cada nota.
2. **Os 5 consertos que mais trazem resultado**, em ordem, cada um com: o que fazer, em qual página, por que importa para o cliente, e se a pessoa faz sozinha ou precisa de ajuda.
3. **Os termos do cliente** (Passo 1), com a fonte de cada um e a página que deveria responder a cada termo.
4. **O que está bom** (para não mexer).
5. **O resto da lista**, curto, para depois.
6. **O que não deu para conferir** e por quê.

Termine com uma pergunta: "Quer que eu já prepare o conserto número 1?" Se ela disser sim e o conserto for no site, siga com a skill `mares-ia-site-completo`.

Regras de escrita: português do Brasil, sem travessão, linguagem de dono de empresa, número só com fonte.

## Guardar a rodada anterior (histórico)

A skill nunca muda com o uso; o que muda é o resultado de cada rodada, salvo na pasta mares.ia. Para não perder a rodada anterior:

1. **Antes do "Está de acordo?" do fechamento, veja se já existe** o **SEO.md** na pasta mares.ia.
2. Se existir, veja de qual empresa é: o nome está no título do arquivo, na primeira linha (no site, no `<title>` da página; na minha-marca, no nome da empresa dentro dela).
   - Se for a mesma empresa, avise em uma linha: "Já existe uma versão de [data]. Vou guardar essa no histórico e salvar a nova no lugar."
   - Se for outra empresa, pare e não mexa em nada. Não diga o nome da outra empresa. Diga: "Esta pasta já tem a análise de SEO de outra empresa. Cada empresa precisa da sua própria pasta mares.ia, para os dados não se misturarem. Abra a pasta certa, ou crie uma nova, e me avise." Só salve depois que a pessoa estiver na pasta certa.
3. **Guarde a anterior** na subpasta **historico** da mares.ia (crie se não existir), com a data dela na frente do nome: por exemplo `historico/2026-11-28_SEO.md`. A data é a que estiver escrita no topo do arquivo; se não houver, use a data em que ele foi salvo. Nunca apague a versão anterior.
4. **Salve a nova com o nome de sempre**, sem data, porque é esse nome que as outras skills leem.
5. Compare as notas e os 5 consertos com a rodada anterior: o que foi resolvido e o que continua.

## Fechamento: a pessoa aprova antes de guardar

Esta regra vale sobre qualquer outra desta skill.

Quando o trabalho estiver pronto, não guarde direto como versão final:

1. Antes de mostrar o resumo final, siga a seção "Guardar a rodada anterior (histórico)": veja se o arquivo já existe na pasta e, se for de outra empresa, siga o que está lá antes de continuar. Assim você já sabe o nome e o lugar do arquivo. Depois mostre o resultado final em poucas linhas: o que vai ficar guardado e onde.
2. Pergunte, com estas palavras: **"Finalizamos aqui. Esta é a versão final. Está de acordo?"**, com as opções A) Estou de acordo, pode guardar · B) Quero ajustar alguma coisa. Se tiver a ferramenta de pergunta com opções, use-a.
3. Se a resposta for B, ajuste o que a pessoa pedir, uma coisa por vez, e pergunte de novo.
4. Só depois do "de acordo", salve o arquivo como versão final e diga em uma linha onde ele ficou guardado. Depois, feche com o próximo passo: "O próximo passo é fazer o conserto número 1. Se for no site, use a skill mares-ia-site-completo."

Se a skill precisou salvar um rascunho antes, para a pessoa ver (por exemplo, a página aberta no navegador), ele continua sendo rascunho até o "de acordo".
