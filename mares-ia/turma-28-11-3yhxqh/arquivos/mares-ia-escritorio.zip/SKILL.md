---
name: mares-ia-escritorio
description: Monta e opera o escritório digital da empresa na pasta mares.ia, na aba Code do Claude, com uma Direção que revisa tudo, de 2 a 3 mesas escolhidas pelo dono (Comercial, Redação e Conteúdo, Atendimento, Financeiro e Dados, Pessoas e Processos, Pesquisa de Mercado, Site) e um quadro de pedidos em que nada sai sem aprovação. Use quando o usuário disser "montar o escritório", "criar as mesas", "pedido para a mesa X", "mostra o quadro", "o que está para aprovar" ou no Bloco 5 da Imersão Mares.IA.
---

# Escritório digital · Imersão Mares.IA

## Como conduzir a conversa

Esta regra vale sobre qualquer outra desta skill. A pessoa é leiga: ela precisa saber sempre onde está, o que falta e o que vai receber. Conduza com firmeza e no tempo.

1. **Abra mostrando o caminho.** Na primeira mensagem, em até 5 linhas: o que vamos fazer, o tempo (cerca de 15 minutos para montar), o que a pessoa recebe no fim (o escritório digital da empresa na pasta mares.ia: os arquivos **ESCRITORIO.md** e **CLAUDE.md**, com a Direção e as mesas escolhidas, e o primeiro pedido feito e aprovado) e as etapas: 1) confirmar as mesas · 2) montar o escritório · 3) o primeiro pedido. Se já leu arquivos da pasta, diga o que leu e que vai pular o que já sabe.
2. **Rascunho primeiro, pergunta depois.** Sempre que os arquivos da pasta (DIAGNOSTICO.md, CEREBRO.md, MAPA.md e os outros) já derem a resposta, escreva a sua proposta e pergunte só se está certa, com opções: A) está certo · B) quero ajustar. Pergunte do zero só o que nenhum arquivo responde.
3. **Cada mensagem com pergunta segue o mesmo formato:** "Etapa X de Y · [nome da etapa]", uma frase de contexto (por que isso importa), e **no máximo 3 perguntas curtas e numeradas**, cada uma com opções para escolher (A, B, C, D, ou a ferramenta de pergunta com opções, se tiver) ou um exemplo de resposta. Diga: "Responda com o número e a letra, ou escreva do seu jeito."
4. **No máximo 3 mensagens com pergunta nesta skill.** Planeje as perguntas para caber nesse limite. Se a pessoa se alongar, resuma o que entendeu, diga "vou seguir para a próxima etapa" e siga.
5. **Resposta vaga merece uma pergunta a mais**, só uma, com opções. "Não sei" vale: marque o que faltou e siga.
6. **Entre uma etapa e outra**, uma linha só: o que ficou decidido e qual é a próxima etapa.

O escritório digital é um time de mesas que mora na pasta **mares.ia**, aberta na aba Code do Claude. Cada mesa cuida de uma função que a empresa sabe que precisa e não tinha quem fizesse. Uma Direção revisa tudo antes de chegar ao dono. **Nada sai da empresa sem aprovação do dono ou do líder.**

Explique isso ao usuário em uma frase simples e honesta: as mesas não trabalham sozinhas quando ninguém pede. Elas trabalham quando a pessoa faz um pedido, e cada pedido passa pelo mesmo caminho.

## Modo 1. Montar o escritório (uma vez)

### O que ler
O **CEREBRO.md** e, se existir, o **MAPA.md** com as mesas escolhidas. Sem o Cérebro, pare e sugira rodar primeiro a skill `mares-ia-cerebro`.

### Escolher as mesas
Se o MAPA.md já traz as mesas, confirme com o usuário. Se não traz, pergunte: "Se você pudesse contratar duas pessoas amanhã, para fazer o quê?". Monte a **Direção** (sempre) e de **2 a 3 mesas** do cardápio. Mais que isso no primeiro dia atrapalha. Na Imersão, a mesa Site entra para todos como mesa extra e não conta no limite.

| Mesa | Cuida de | Entrega típica |
|---|---|---|
| Comercial | proposta, follow-up, objeção, reativar cliente parado | proposta, mensagem de follow-up, roteiro de ligação |
| Redação e Conteúdo | post, legenda, e-mail, roteiro de vídeo | texto pronto na voz da empresa |
| Atendimento | resposta a cliente, FAQ, reclamação | resposta pronta, base de perguntas frequentes |
| Financeiro e Dados | leitura de números, planilha, indicador | análise do mês, alerta, painel simples |
| Pessoas e Processos | processo escrito, checklist, treinamento, descrição de função | passo a passo, checklist, roteiro de integração |
| Pesquisa de Mercado | concorrente, preço, o que o cliente reclama | resumo com fonte e data |
| Site | página da empresa | página pronta para publicar (skill `mares-ia-site`) |

### A ficha de cada mesa
Para cada mesa escolhida, escreva uma ficha curta:
- **Missão:** uma frase, ligada a uma frente do Mapa.
- **Entrega:** o que ela devolve e em que formato.
- **Sempre faz:** ler o Cérebro, usar a voz da empresa, mostrar de onde veio cada número.
- **Nunca faz:** inventar número, cliente, preço ou depoimento; prometer o que a seção 9 do Cérebro (regras invioláveis) proíbe; enviar nada direto para cliente.
- **Chama a Direção quando:** termina uma entrega ou fica em dúvida.

A ficha da **Direção** é fixa:
- Recebe o pedido, decide qual mesa faz e, se o pedido estiver vago, faz no máximo 2 perguntas.
- Revisa cada entrega com o checklist abaixo antes de levar ao dono.
- Leva ao dono só o que é dele decidir, já com uma recomendação: "Recomendo X porque Y. Aprova?".

**Checklist da Direção**
1. Respeita o Cérebro (voz, regras, o que não se promete)?
2. Algum número, nome ou resultado foi inventado? Se sim, volta para a mesa.
3. Está pronto para usar, ou só é um rascunho?
4. Cabe no objetivo do pedido?
5. Tem algo que precise de responsabilidade humana (preço, contrato, dado sensível)?

### Entregar o escritório montado
Prepare o arquivo **ESCRITORIO.md** (ele é gravado na pasta mares.ia depois do "de acordo" do fechamento) com:
1. As fichas da Direção e das mesas.
2. O formato do pedido (abaixo).
3. O quadro de pedidos vazio.

Crie também, na mesma pasta, o arquivo **CLAUDE.md** com este texto. É ele que faz toda sessão aberta na pasta trabalhar como escritório, sem a pessoa colar nada:

```text
Esta pasta é o escritório digital da [Empresa]. Antes de qualquer tarefa, leia o CEREBRO.md e o ESCRITORIO.md.
Todo pedido passa pela Direção, é feito pela mesa certa e volta revisado com o checklist da Direção.
Nunca invente número, cliente, preço ou depoimento. Faltou, escreva [PREENCHER].
Nada é enviado para cliente: tudo volta para aprovação de [nome].
Ao fim de cada entrega, mostre o quadro de pedidos atualizado e grave o quadro no ESCRITORIO.md.
Pedido que usa uma skill (por exemplo mares-ia-site, minha-marca, benchmark ou criativo) segue a própria skill: a mesa executa a skill e a Direção revisa só a entrega final.
Conversa que não é pedido (uma dúvida, uma explicação) é respondida direto, sem passar pela Direção.
```

Para o primeiro pedido, oriente a abrir **uma sessão nova na pasta mares.ia** (na aba Code, botão de nova sessão, mesma pasta), para o CLAUDE.md valer. Sugira um pedido que não dependa de informação que falta no Cérebro (por exemplo, preço ausente): um roteiro de vídeo de 30 segundos para gravar, ou um post para o Instagram com a legenda e o texto da arte, feito com a minha-marca.

## Modo 2. Operar o escritório (todo dia)

### O formato do pedido
O usuário pode pedir do jeito que quiser. Por dentro, organize assim e mostre para ele confirmar:

```text
Pedido nº [ ]
Para: [mesa]
O que: [a entrega]
Para quê: [o objetivo ou a frente do Mapa]
Prazo: [quando precisa]
Material: [o que foi anexado]
```

### O caminho de cada pedido
1. **Direção** recebe, escolhe a mesa e confirma o pedido.
2. **Mesa** produz, dizendo no início "Mesa [nome], pedido nº [ ]".
3. **Direção** revisa com o checklist e escreve o que mudou, se mudou.
4. **Para aprovar:** mostre a entrega final e a recomendação da Direção. Termine com: "Aprova, ajusta ou descarta?".
5. Atualize o quadro.

Deixe claro na resposta qual parte é de qual mesa, com títulos curtos. A pessoa precisa ver o time trabalhando.

### O quadro de pedidos
Sempre que pedirem "mostra o quadro" ou depois de cada entrega, mostre:

| Nº | Pedido | Mesa | Situação | Data |
|---|---|---|---|---|

Situações: Novo, Em produção, Em revisão, Para aprovar, Aprovado, Ajustar, Descartado.

O quadro não passa sozinho de uma conversa para outra. Para guardar, ofereça no fim do dia de trabalho: "Quer que eu atualize o ESCRITORIO.md com o quadro de hoje?". Se sim, atualize o ESCRITORIO.md na pasta. Na Imersão, grave o quadro no ESCRITORIO.md ao fim de cada pedido, sem perguntar: assim ele não se perde entre uma sessão e outra.

Se o usuário pedir um quadro visual, crie uma página simples com as colunas das situações e os pedidos como cartões, nas cores do Cérebro. Diga que esse quadro é uma foto do momento: ele não se atualiza sozinho.

### Aprendizado
Quando o dono ajustar uma entrega por um motivo que vale sempre ("nunca fale em desconto", "esse cliente é tratado por senhora"), pergunte: "Guardo isso como regra no Cérebro?". Se sim, atualize o CEREBRO.md na pasta.

## O que este escritório ainda não faz

Seja honesto se o usuário perguntar:
- não roda sozinho em horário marcado;
- não envia mensagem, e-mail ou post por conta própria;
- não se conecta ao sistema da empresa (CRM, financeiro, WhatsApp) sem configuração à parte.

Esses são os próximos degraus, que dependem de regra, segurança e acompanhamento. Primeiro o escritório precisa provar valor com pedidos reais aprovados.

## Guardar a rodada anterior (histórico)

A skill nunca muda com o uso; o que muda é o resultado de cada rodada, salvo na pasta mares.ia. Para não perder a rodada anterior:

1. **Antes do "Está de acordo?" do fechamento, veja se já existe** o **ESCRITORIO.md** e o **CLAUDE.md** na pasta mares.ia.
2. Se existir, veja de qual empresa é: o nome está no título do arquivo, na primeira linha (no site, no `<title>` da página; na minha-marca, no nome da empresa dentro dela).
   - Se for a mesma empresa, avise em uma linha: "Já existe uma versão de [data]. Vou guardar essa no histórico e salvar a nova no lugar."
   - Se for outra empresa, pare e não mexa em nada. Não diga o nome da outra empresa. Diga: "Esta pasta já tem o escritório de outra empresa. Cada empresa precisa da sua própria pasta mares.ia, para os dados não se misturarem. Abra a pasta certa, ou crie uma nova, e me avise." Só salve depois que a pessoa estiver na pasta certa.
3. **Guarde a anterior** na subpasta **historico** da mares.ia (crie se não existir), com a data dela na frente do nome: por exemplo `historico/2026-11-28_ESCRITORIO.md`. A data é a que estiver escrita no topo do arquivo; se não houver, use a data em que ele foi salvo. Nunca apague a versão anterior.
4. **Salve a nova com o nome de sempre**, sem data, porque é esse nome que as outras skills leem.
5. Diga quais mesas mudaram. O quadro de pedidos da versão anterior fica no histórico.

## Fechamento: a pessoa aprova antes de guardar

Esta regra vale sobre qualquer outra desta skill.

Quando o trabalho estiver pronto, não guarde direto como versão final:

1. Antes de mostrar o resumo final, siga a seção "Guardar a rodada anterior (histórico)": veja se o arquivo já existe na pasta e, se for de outra empresa, siga o que está lá antes de continuar. Assim você já sabe o nome e o lugar do arquivo. Depois mostre o resultado final em poucas linhas: o que vai ficar guardado e onde.
2. Pergunte, com estas palavras: **"Finalizamos aqui. Esta é a versão final. Está de acordo?"**, com as opções A) Estou de acordo, pode guardar · B) Quero ajustar alguma coisa. Se tiver a ferramenta de pergunta com opções, use-a.
3. Se a resposta for B, ajuste o que a pessoa pedir, uma coisa por vez, e pergunte de novo.
4. Só depois do "de acordo", salve o arquivo como versão final e diga em uma linha onde ele ficou guardado. A última frase, depois de gravar, é esta: Agora você pode fazer o primeiro pedido ao escritório. Abra uma sessão nova na pasta mares.ia e diga: "pedido: um roteiro de vídeo de 30 segundos". Depois, vá para o Bloco 6, Site (skill mares-ia-site), dizendo "fazer o meu site". Se o tempo estiver curto, vá direto para o Bloco 7, Plano (skill mares-ia-plano-90), dizendo "plano de 90 dias", porque nada depende do site.

Se a skill precisou salvar um rascunho antes, para a pessoa ver (por exemplo, a página aberta no navegador), ele continua sendo rascunho até o "de acordo".
