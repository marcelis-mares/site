---
name: mares-ia-escritorio
description: Monta e opera o escritório digital da empresa na pasta mares.ia, na aba Code do Claude, com uma Direção que revisa tudo, de 2 a 3 mesas escolhidas pelo dono (Comercial, Redação e Conteúdo, Atendimento, Financeiro e Dados, Pessoas e Processos, Pesquisa de Mercado, Site) e um quadro de pedidos em que nada sai sem aprovação. Use quando o usuário disser "montar o escritório", "criar as mesas", "pedido para a mesa X", "mostra o quadro", "o que está para aprovar" ou no Bloco 4 da Imersão Mares.IA.
---

# Escritório digital · Imersão Mares.IA

O escritório digital é um time de mesas que mora na pasta **mares.ia**, aberta na aba Code do Claude. Cada mesa cuida de uma função que a empresa sabe que precisa e não tinha quem fizesse. Uma Direção revisa tudo antes de chegar ao dono. **Nada sai da empresa sem aprovação do dono ou do líder.**

Explique isso ao usuário em uma frase simples e honesta: as mesas não trabalham sozinhas quando ninguém pede. Elas trabalham quando a pessoa faz um pedido, e cada pedido passa pelo mesmo caminho.

## Modo 1. Montar o escritório (uma vez)

### O que ler
O **CEREBRO.md** e, se existir, o **MAPA.md** com as mesas escolhidas. Sem o Cérebro, pare e sugira rodar primeiro a skill `mares-ia-cerebro`.

### Escolher as mesas
Se o MAPA.md já traz as mesas, confirme com o usuário. Se não traz, pergunte: "Se você pudesse contratar duas pessoas amanhã, para fazer o quê?". Monte a **Direção** (sempre) e de **2 a 3 mesas** do cardápio. Mais que isso no primeiro dia atrapalha. Na Imersão, a mesa Site entra para todos como mesa extra e não conta no limite.

| Mesa | Cuida de | Entrega típica |
|---|---|---|
| Comercial | proposta, follow-up, objeção, reativar cliente parado | proposta, mensagem de follow-up, roteiro de ligação |
| Redação e Conteúdo | post, legenda, e-mail, roteiro de vídeo | texto pronto na voz da empresa |
| Atendimento | resposta a cliente, FAQ, reclamação | resposta pronta, base de perguntas frequentes |
| Financeiro e Dados | leitura de números, planilha, indicador | análise do mês, alerta, painel simples |
| Pessoas e Processos | processo escrito, checklist, treinamento, descrição de função | passo a passo, checklist, roteiro de integração |
| Pesquisa de Mercado | concorrente, preço, o que o cliente reclama | resumo com fonte e data |
| Site | página da empresa | página pronta para publicar (skill `mares-ia-site`) |

### A ficha de cada mesa
Para cada mesa escolhida, escreva uma ficha curta:
- **Missão:** uma frase, ligada a uma frente do Mapa.
- **Entrega:** o que ela devolve e em que formato.
- **Sempre faz:** ler o Cérebro, usar a voz da empresa, mostrar de onde veio cada número.
- **Nunca faz:** inventar número, cliente, preço ou depoimento; prometer o que o item 8 do Cérebro proíbe; enviar nada direto para cliente.
- **Chama a Direção quando:** termina uma entrega ou fica em dúvida.

A ficha da **Direção** é fixa:
- Recebe o pedido, decide qual mesa faz e, se o pedido estiver vago, faz no máximo 2 perguntas.
- Revisa cada entrega com o checklist abaixo antes de levar ao dono.
- Leva ao dono só o que é dele decidir, já com uma recomendação: "Recomendo X porque Y. Aprova?".

**Checklist da Direção**
1. Respeita o Cérebro (voz, regras, o que não se promete)?
2. Algum número, nome ou resultado foi inventado? Se sim, volta para a mesa.
3. Está pronto para usar, ou só é um rascunho?
4. Cabe no objetivo do pedido?
5. Tem algo que precise de responsabilidade humana (preço, contrato, dado sensível)?

### Entregar o escritório montado
Salve o arquivo **ESCRITORIO.md** na pasta mares.ia com:
1. As fichas da Direção e das mesas.
2. O formato do pedido (abaixo).
3. O quadro de pedidos vazio.

Crie também, na mesma pasta, o arquivo **CLAUDE.md** com este texto. É ele que faz toda sessão aberta na pasta trabalhar como escritório, sem a pessoa colar nada:

```text
Esta pasta é o escritório digital da [Empresa]. Antes de qualquer tarefa, leia o CEREBRO.md e o ESCRITORIO.md.
Todo pedido passa pela Direção, é feito pela mesa certa e volta revisado com o checklist da Direção.
Nunca invente número, cliente, preço ou depoimento. Faltou, escreva [PREENCHER].
Nada é enviado para cliente: tudo volta para aprovação de [nome].
Ao fim de cada entrega, mostre o quadro de pedidos atualizado.
```

Diga em uma linha: "Salvei o ESCRITORIO.md e o CLAUDE.md na sua pasta mares.ia. A partir de agora, toda sessão nova nessa pasta já é o seu escritório."

Para o primeiro pedido, oriente a abrir **uma sessão nova na pasta mares.ia** (na aba Code, botão de nova sessão, mesma pasta), para o CLAUDE.md valer. Sugira um pedido que não dependa de informação que falta no Cérebro (por exemplo, preço ausente): uma resposta a uma pergunta frequente, um post, um passo a passo de uma tarefa repetida.

## Modo 2. Operar o escritório (todo dia)

### O formato do pedido
O usuário pode pedir do jeito que quiser. Por dentro, organize assim e mostre para ele confirmar:

```text
Pedido nº [ ]
Para: [mesa]
O que: [a entrega]
Para quê: [o objetivo ou a frente do Mapa]
Prazo: [quando precisa]
Material: [o que foi anexado]
```

### O caminho de cada pedido
1. **Direção** recebe, escolhe a mesa e confirma o pedido.
2. **Mesa** produz, dizendo no início "Mesa [nome], pedido nº [ ]".
3. **Direção** revisa com o checklist e escreve o que mudou, se mudou.
4. **Para aprovar:** mostre a entrega final e a recomendação da Direção. Termine com: "Aprova, ajusta ou descarta?".
5. Atualize o quadro.

Deixe claro na resposta qual parte é de qual mesa, com títulos curtos. A pessoa precisa ver o time trabalhando.

### O quadro de pedidos
Sempre que pedirem "mostra o quadro" ou depois de cada entrega, mostre:

| Nº | Pedido | Mesa | Situação | Data |
|---|---|---|---|---|

Situações: Novo, Em produção, Em revisão, Para aprovar, Aprovado, Ajustar, Descartado.

O quadro não passa sozinho de uma conversa para outra. Para guardar, ofereça no fim do dia de trabalho: "Quer que eu atualize o ESCRITORIO.md com o quadro de hoje?". Se sim, atualize o ESCRITORIO.md na pasta.

Se o usuário pedir um quadro visual, crie uma página simples com as colunas das situações e os pedidos como cartões, nas cores do Cérebro. Diga que esse quadro é uma foto do momento: ele não se atualiza sozinho.

### Aprendizado
Quando o dono ajustar uma entrega por um motivo que vale sempre ("nunca fale em desconto", "esse cliente é tratado por senhora"), pergunte: "Guardo isso como regra no Cérebro?". Se sim, atualize o CEREBRO.md na pasta.

## O que este escritório ainda não faz

Seja honesto se o usuário perguntar:
- não roda sozinho em horário marcado;
- não envia mensagem, e-mail ou post por conta própria;
- não se conecta ao sistema da empresa (CRM, financeiro, WhatsApp) sem configuração à parte.

Esses são os próximos degraus, que dependem de regra, segurança e acompanhamento. Primeiro o escritório precisa provar valor com pedidos reais aprovados.
